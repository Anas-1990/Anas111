import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { SubscriptionManager } from '../app/components/SubscriptionManager';
import { useApi } from '../app/utils/api';

// Mock the API hook
jest.mock('../app/utils/api', () => ({
  useApi: jest.fn(),
}));

describe('SubscriptionManager', () => {
  const mockUserId = 'user123';
  const mockSubscription = {
    id: 'sub_123456',
    status: 'active',
    tier: 'Pro',
    current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    api_calls_limit: 1000,
    api_calls_used: 342,
    payment_method: {
      brand: 'visa',
      last4: '4242',
      exp_month: 12,
      exp_year: 2025
    }
  };

  beforeEach(() => {
    // Setup default mock implementation
    useApi.mockReturnValue({
      api: {
        subscriptions: {
          get: jest.fn().mockResolvedValue(mockSubscription),
          upgrade: jest.fn().mockResolvedValue({ success: true }),
          cancel: jest.fn().mockResolvedValue({ success: true }),
          updatePaymentMethod: jest.fn().mockResolvedValue({ success: true }),
        }
      },
      loading: false,
      error: null
    });
  });

  test('renders subscription details correctly', async () => {
    render(<SubscriptionManager userId={mockUserId} />);
    
    // Wait for subscription data to load
    await waitFor(() => {
      expect(screen.getByText('Subscription Details')).toBeInTheDocument();
    });
    
    // Check if subscription details are displayed
    expect(screen.getByText('Pro')).toBeInTheDocument();
    expect(screen.getByText('Active')).toBeInTheDocument();
    expect(screen.getByText(/342 \/ 1000/)).toBeInTheDocument();
    expect(screen.getByText(/visa/i)).toBeInTheDocument();
    expect(screen.getByText(/•••• 4242/)).toBeInTheDocument();
  });

  test('handles upgrade to Pro plan', async () => {
    // Mock a Basic subscription
    useApi.mockReturnValue({
      api: {
        subscriptions: {
          get: jest.fn().mockResolvedValue({
            ...mockSubscription,
            tier: 'Basic'
          }),
          upgrade: jest.fn().mockResolvedValue({ success: true }),
        }
      },
      loading: false,
      error: null
    });

    render(<SubscriptionManager userId={mockUserId} />);
    
    // Wait for subscription data to load
    await waitFor(() => {
      expect(screen.getByText('Basic')).toBeInTheDocument();
    });
    
    // Click upgrade button
    const upgradeButton = screen.getByText('Upgrade to Pro');
    fireEvent.click(upgradeButton);
    
    // Check if API was called
    await waitFor(() => {
      expect(useApi().api.subscriptions.upgrade).toHaveBeenCalledWith(
        mockUserId,
        'Pro'
      );
    });
    
    // Check for success message
    await waitFor(() => {
      expect(screen.getByText(/Successfully upgraded to Pro plan/)).toBeInTheDocument();
    });
  });

  test('handles downgrade to Basic plan', async () => {
    render(<SubscriptionManager userId={mockUserId} />);
    
    // Wait for subscription data to load
    await waitFor(() => {
      expect(screen.getByText('Pro')).toBeInTheDocument();
    });
    
    // Click downgrade button
    const downgradeButton = screen.getByText('Downgrade to Basic');
    fireEvent.click(downgradeButton);
    
    // Check if API was called
    await waitFor(() => {
      expect(useApi().api.subscriptions.upgrade).toHaveBeenCalledWith(
        mockUserId,
        'Basic'
      );
    });
    
    // Check for success message
    await waitFor(() => {
      expect(screen.getByText(/Successfully upgraded to Basic plan/)).toBeInTheDocument();
    });
  });

  test('handles subscription cancellation', async () => {
    render(<SubscriptionManager userId={mockUserId} />);
    
    // Wait for subscription data to load
    await waitFor(() => {
      expect(screen.getByText('Pro')).toBeInTheDocument();
    });
    
    // Click cancel button
    const cancelButton = screen.getByText('Cancel Subscription');
    fireEvent.click(cancelButton);
    
    // Check if API was called
    await waitFor(() => {
      expect(useApi().api.subscriptions.cancel).toHaveBeenCalledWith(
        mockUserId
      );
    });
    
    // Check for success message
    await waitFor(() => {
      expect(screen.getByText(/Subscription canceled/)).toBeInTheDocument();
    });
  });

  test('handles payment method update', async () => {
    render(<SubscriptionManager userId={mockUserId} />);
    
    // Wait for subscription data to load
    await waitFor(() => {
      expect(screen.getByText('Pro')).toBeInTheDocument();
    });
    
    // Click update payment method button
    const updateButton = screen.getByText('Update');
    fireEvent.click(updateButton);
    
    // Check if API was called
    await waitFor(() => {
      expect(useApi().api.subscriptions.updatePaymentMethod).toHaveBeenCalledWith(
        mockUserId
      );
    });
    
    // Check for success message
    await waitFor(() => {
      expect(screen.getByText(/Payment method updated successfully/)).toBeInTheDocument();
    });
  });

  test('displays loading state', () => {
    // Mock loading state
    useApi.mockReturnValue({
      api: {
        subscriptions: {
          get: jest.fn().mockResolvedValue(mockSubscription),
        }
      },
      loading: true,
      error: null
    });

    render(<SubscriptionManager userId={mockUserId} />);
    
    // Check for loading indicator
    expect(screen.getByTestId('loading-indicator')).toBeInTheDocument();
  });

  test('displays error message', async () => {
    // Mock error state
    useApi.mockReturnValue({
      api: {
        subscriptions: {
          get: jest.fn().mockRejectedValue(new Error('Failed to fetch subscription')),
        }
      },
      loading: false,
      error: 'Failed to fetch subscription'
    });

    render(<SubscriptionManager userId={mockUserId} />);
    
    // Check for error message
    await waitFor(() => {
      expect(screen.getByText(/Failed to fetch subscription/)).toBeInTheDocument();
    });
  });
});
