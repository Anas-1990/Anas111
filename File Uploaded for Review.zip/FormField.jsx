import React from 'react';
import { FiEye, FiEyeOff } from 'react-icons/fi';

const FormField = ({
  label,
  type = 'text',
  id,
  name,
  value,
  onChange,
  placeholder,
  error,
  helper,
  required = false,
  disabled = false,
  className = '',
  inputClassName = '',
  labelClassName = '',
  fullWidth = true,
  min,
  max,
  step,
  options = [],
  multiple = false,
  rows = 3,
  autoFocus = false,
  onBlur,
  onFocus,
}) => {
  const [showPassword, setShowPassword] = React.useState(false);
  const inputId = id || name;

  const renderInput = () => {
    switch (type) {
      case 'textarea':
        return (
          <textarea
            id={inputId}
            name={name}
            value={value}
            onChange={onChange}
            onBlur={onBlur}
            onFocus={onFocus}
            placeholder={placeholder}
            disabled={disabled}
            required={required}
            rows={rows}
            autoFocus={autoFocus}
            className={`
              block w-full rounded-md shadow-sm 
              ${error ? 'border-red-300 text-red-900 placeholder-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-indigo-500 focus:border-indigo-500'} 
              ${disabled ? 'bg-gray-100 cursor-not-allowed' : ''}
              ${inputClassName}
            `}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={error ? `${inputId}-error` : helper ? `${inputId}-helper` : undefined}
          />
        );
      
      case 'select':
        return (
          <select
            id={inputId}
            name={name}
            value={value}
            onChange={onChange}
            onBlur={onBlur}
            onFocus={onFocus}
            disabled={disabled}
            required={required}
            multiple={multiple}
            autoFocus={autoFocus}
            className={`
              block w-full rounded-md shadow-sm 
              ${error ? 'border-red-300 text-red-900 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-indigo-500 focus:border-indigo-500'} 
              ${disabled ? 'bg-gray-100 cursor-not-allowed' : ''}
              ${inputClassName}
            `}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={error ? `${inputId}-error` : helper ? `${inputId}-helper` : undefined}
          >
            {placeholder && (
              <option value="" disabled>
                {placeholder}
              </option>
            )}
            {options.map((option, index) => (
              <option key={index} value={option.value || option}>
                {option.label || option}
              </option>
            ))}
          </select>
        );
      
      case 'checkbox':
        return (
          <div className="flex items-center">
            <input
              id={inputId}
              name={name}
              type="checkbox"
              checked={value}
              onChange={onChange}
              onBlur={onBlur}
              onFocus={onFocus}
              disabled={disabled}
              required={required}
              autoFocus={autoFocus}
              className={`
                h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded
                ${disabled ? 'bg-gray-100 cursor-not-allowed' : ''}
                ${inputClassName}
              `}
              aria-invalid={error ? 'true' : 'false'}
              aria-describedby={error ? `${inputId}-error` : helper ? `${inputId}-helper` : undefined}
            />
            {label && (
              <label
                htmlFor={inputId}
                className={`ml-2 block text-sm text-gray-900 ${labelClassName}`}
              >
                {label}
                {required && <span className="text-red-500 ml-1">*</span>}
              </label>
            )}
          </div>
        );
      
      case 'radio':
        return (
          <div className="flex items-center">
            <input
              id={inputId}
              name={name}
              type="radio"
              checked={value}
              onChange={onChange}
              onBlur={onBlur}
              onFocus={onFocus}
              disabled={disabled}
              required={required}
              autoFocus={autoFocus}
              className={`
                h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300
                ${disabled ? 'bg-gray-100 cursor-not-allowed' : ''}
                ${inputClassName}
              `}
              aria-invalid={error ? 'true' : 'false'}
              aria-describedby={error ? `${inputId}-error` : helper ? `${inputId}-helper` : undefined}
            />
            {label && (
              <label
                htmlFor={inputId}
                className={`ml-2 block text-sm text-gray-900 ${labelClassName}`}
              >
                {label}
                {required && <span className="text-red-500 ml-1">*</span>}
              </label>
            )}
          </div>
        );
      
      case 'password':
        return (
          <div className="relative">
            <input
              id={inputId}
              name={name}
              type={showPassword ? 'text' : 'password'}
              value={value}
              onChange={onChange}
              onBlur={onBlur}
              onFocus={onFocus}
              placeholder={placeholder}
              disabled={disabled}
              required={required}
              autoFocus={autoFocus}
              className={`
                block w-full rounded-md shadow-sm pr-10
                ${error ? 'border-red-300 text-red-900 placeholder-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-indigo-500 focus:border-indigo-500'} 
                ${disabled ? 'bg-gray-100 cursor-not-allowed' : ''}
                ${inputClassName}
              `}
              aria-invalid={error ? 'true' : 'false'}
              aria-describedby={error ? `${inputId}-error` : helper ? `${inputId}-helper` : undefined}
            />
            <button
              type="button"
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-500"
              onClick={() => setShowPassword(!showPassword)}
              tabIndex="-1"
            >
              {showPassword ? (
                <FiEyeOff className="h-5 w-5" aria-hidden="true" />
              ) : (
                <FiEye className="h-5 w-5" aria-hidden="true" />
              )}
            </button>
          </div>
        );
      
      default:
        return (
          <input
            id={inputId}
            name={name}
            type={type}
            value={value}
            onChange={onChange}
            onBlur={onBlur}
            onFocus={onFocus}
            placeholder={placeholder}
            disabled={disabled}
            required={required}
            min={min}
            max={max}
            step={step}
            autoFocus={autoFocus}
            className={`
              block rounded-md shadow-sm 
              ${error ? 'border-red-300 text-red-900 placeholder-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-indigo-500 focus:border-indigo-500'} 
              ${disabled ? 'bg-gray-100 cursor-not-allowed' : ''}
              ${fullWidth ? 'w-full' : ''}
              ${inputClassName}
            `}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={error ? `${inputId}-error` : helper ? `${inputId}-helper` : undefined}
          />
        );
    }
  };

  return (
    <div className={`${className}`}>
      {label && type !== 'checkbox' && type !== 'radio' && (
        <label
          htmlFor={inputId}
          className={`block text-sm font-medium text-gray-700 mb-1 ${labelClassName}`}
        >
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      
      {renderInput()}
      
      {helper && !error && (
        <p className="mt-1 text-sm text-gray-500" id={`${inputId}-helper`}>
          {helper}
        </p>
      )}
      
      {error && (
        <p className="mt-1 text-sm text-red-600" id={`${inputId}-error`}>
          {error}
        </p>
      )}
    </div>
  );
};

export default FormField;
