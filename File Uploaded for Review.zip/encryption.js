import crypto from 'crypto';

/**
 * Utility class for handling encryption and decryption of sensitive data
 */
class EncryptionService {
  constructor(encryptionKey = process.env.ENCRYPTION_KEY) {
    if (!encryptionKey || encryptionKey.length < 32) {
      throw new Error('Invalid encryption key. Must be at least 32 characters long.');
    }
    
    // Use the first 32 bytes of the key for AES-256
    this.encryptionKey = Buffer.from(encryptionKey.slice(0, 32));
    this.algorithm = 'aes-256-cbc';
  }

  /**
   * Encrypts data using AES-256-CBC
   * @param {string|object} data - Data to encrypt (string or object that will be JSON stringified)
   * @returns {string} - Encrypted data as base64 string with IV prepended
   */
  encrypt(data) {
    try {
      // Convert object to string if needed
      const dataString = typeof data === 'object' ? JSON.stringify(data) : data;
      
      // Generate a random initialization vector
      const iv = crypto.randomBytes(16);
      
      // Create cipher
      const cipher = crypto.createCipheriv(this.algorithm, this.encryptionKey, iv);
      
      // Encrypt the data
      let encrypted = cipher.update(dataString, 'utf8', 'base64');
      encrypted += cipher.final('base64');
      
      // Prepend the IV to the encrypted data (IV is needed for decryption)
      const result = iv.toString('base64') + ':' + encrypted;
      
      return result;
    } catch (error) {
      console.error('Encryption error:', error);
      throw new Error('Failed to encrypt data');
    }
  }

  /**
   * Decrypts data that was encrypted with the encrypt method
   * @param {string} encryptedData - Encrypted data as base64 string with IV prepended
   * @param {boolean} parseJson - Whether to parse the decrypted result as JSON
   * @returns {string|object} - Decrypted data
   */
  decrypt(encryptedData, parseJson = false) {
    try {
      // Split the IV and encrypted data
      const parts = encryptedData.split(':');
      if (parts.length !== 2) {
        throw new Error('Invalid encrypted data format');
      }
      
      const iv = Buffer.from(parts[0], 'base64');
      const encrypted = parts[1];
      
      // Create decipher
      const decipher = crypto.createDecipheriv(this.algorithm, this.encryptionKey, iv);
      
      // Decrypt the data
      let decrypted = decipher.update(encrypted, 'base64', 'utf8');
      decrypted += decipher.final('utf8');
      
      // Parse as JSON if requested
      return parseJson ? JSON.parse(decrypted) : decrypted;
    } catch (error) {
      console.error('Decryption error:', error);
      throw new Error('Failed to decrypt data');
    }
  }

  /**
   * Generates a secure hash of data using SHA-256
   * @param {string} data - Data to hash
   * @param {string} salt - Optional salt to add to the data
   * @returns {string} - Hashed data as hex string
   */
  hash(data, salt = '') {
    try {
      return crypto
        .createHash('sha256')
        .update(data + salt)
        .digest('hex');
    } catch (error) {
      console.error('Hashing error:', error);
      throw new Error('Failed to hash data');
    }
  }

  /**
   * Generates a random token of specified length
   * @param {number} length - Length of token to generate
   * @returns {string} - Random token as hex string
   */
  generateToken(length = 32) {
    try {
      return crypto.randomBytes(length).toString('hex');
    } catch (error) {
      console.error('Token generation error:', error);
      throw new Error('Failed to generate token');
    }
  }
}

export default EncryptionService;
