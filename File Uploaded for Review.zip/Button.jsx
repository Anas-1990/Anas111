import React from 'react';
import { FiArrowRight, FiCheck } from 'react-icons/fi';

const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  isLoading = false,
  disabled = false,
  fullWidth = false,
  type = 'button',
  onClick,
  className = '',
  ...props
}) => {
  // Variant styles
  const variantStyles = {
    primary: 'bg-indigo-600 hover:bg-indigo-700 text-white focus:ring-indigo-500',
    secondary: 'bg-white border-gray-300 border text-gray-700 hover:bg-gray-50 focus:ring-indigo-500',
    success: 'bg-green-600 hover:bg-green-700 text-white focus:ring-green-500',
    danger: 'bg-red-600 hover:bg-red-700 text-white focus:ring-red-500',
    warning: 'bg-yellow-500 hover:bg-yellow-600 text-white focus:ring-yellow-500',
    info: 'bg-blue-500 hover:bg-blue-600 text-white focus:ring-blue-500',
    ghost: 'bg-transparent hover:bg-gray-100 text-gray-700 focus:ring-gray-500',
    link: 'bg-transparent text-indigo-600 hover:text-indigo-800 hover:underline p-0 focus:ring-0'
  };

  // Size styles
  const sizeStyles = {
    xs: 'px-2.5 py-1.5 text-xs',
    sm: 'px-3 py-2 text-sm',
    md: 'px-4 py-2 text-sm',
    lg: 'px-4 py-2 text-base',
    xl: 'px-6 py-3 text-base'
  };

  // Icon size based on button size
  const iconSizes = {
    xs: 'h-3 w-3',
    sm: 'h-4 w-4',
    md: 'h-5 w-5',
    lg: 'h-5 w-5',
    xl: 'h-6 w-6'
  };

  // Combine all styles
  const buttonClasses = `
    inline-flex items-center justify-center
    font-medium rounded-md
    focus:outline-none focus:ring-2 focus:ring-offset-2
    transition-colors duration-200
    ${variantStyles[variant] || variantStyles.primary}
    ${sizeStyles[size] || sizeStyles.md}
    ${fullWidth ? 'w-full' : ''}
    ${disabled || isLoading ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
    ${variant !== 'link' ? 'shadow-sm' : ''}
    ${className}
  `;

  // Determine icon component
  const IconComponent = icon;
  const iconClass = `${iconSizes[size]} ${iconPosition === 'left' ? 'mr-2 -ml-1' : 'ml-2 -mr-1'}`;

  // Loading spinner
  const LoadingSpinner = () => (
    <svg className={`animate-spin ${iconSizes[size]} ${iconPosition === 'left' ? 'mr-2 -ml-1' : 'ml-2 -mr-1'}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
  );

  return (
    <button
      type={type}
      className={buttonClasses}
      disabled={disabled || isLoading}
      onClick={onClick}
      {...props}
    >
      {isLoading ? (
        <>
          {iconPosition === 'left' && <LoadingSpinner />}
          {children}
          {iconPosition === 'right' && <LoadingSpinner />}
        </>
      ) : (
        <>
          {icon && iconPosition === 'left' && <IconComponent className={iconClass} aria-hidden="true" />}
          {children}
          {icon && iconPosition === 'right' && <IconComponent className={iconClass} aria-hidden="true" />}
        </>
      )}
    </button>
  );
};

// Predefined button variants
export const PrimaryButton = (props) => <Button variant="primary" {...props} />;
export const SecondaryButton = (props) => <Button variant="secondary" {...props} />;
export const SuccessButton = (props) => <Button variant="success" {...props} />;
export const DangerButton = (props) => <Button variant="danger" {...props} />;
export const LinkButton = (props) => <Button variant="link" {...props} />;

// Common action buttons
export const SubmitButton = ({ children = 'Submit', ...props }) => (
  <Button type="submit" variant="primary" {...props}>
    {children}
  </Button>
);

export const CancelButton = ({ children = 'Cancel', ...props }) => (
  <Button variant="secondary" {...props}>
    {children}
  </Button>
);

export const ContinueButton = ({ children = 'Continue', ...props }) => (
  <Button variant="primary" icon={FiArrowRight} iconPosition="right" {...props}>
    {children}
  </Button>
);

export const SaveButton = ({ children = 'Save', ...props }) => (
  <Button variant="primary" icon={FiCheck} {...props}>
    {children}
  </Button>
);

export default Button;
