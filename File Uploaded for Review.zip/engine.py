import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

from sqlalchemy.orm import Session

from ..models.database import (
    User, AITool, Workflow, WorkflowStep, 
    WorkflowExecution, StepExecution, APIUsage
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OrchestrationEngine:
    """
    Main orchestration engine that coordinates the execution of AI tool workflows.
    """
    
    def __init__(self, db_session: Session):
        self.db_session = db_session
        self.tool_registry = {}  # Will be populated with tool instances
    
    def register_tool(self, tool_name: str, tool_instance: Any) -> None:
        """Register an AI tool instance with the orchestration engine."""
        self.tool_registry[tool_name] = tool_instance
        logger.info(f"Registered tool: {tool_name}")
    
    def execute_workflow(self, workflow_id: int, user_id: int, user_prompt: str) -> Dict[str, Any]:
        """
        Execute a workflow with the given user prompt.
        
        Args:
            workflow_id: ID of the workflow to execute
            user_id: ID of the user executing the workflow
            user_prompt: User's input prompt for the workflow
            
        Returns:
            Dict containing execution results and status
        """
        # Get the workflow
        workflow = self.db_session.query(Workflow).filter(Workflow.id == workflow_id).first()
        if not workflow:
            return {"status": "failed", "error": f"Workflow with ID {workflow_id} not found"}
        
        # Get the user
        user = self.db_session.query(User).filter(User.id == user_id).first()
        if not user:
            return {"status": "failed", "error": f"User with ID {user_id} not found"}
        
        # Check if user has enough API calls remaining
        if user.api_calls_used >= user.api_calls_limit and not user.is_enterprise:
            return {"status": "failed", "error": "API call limit exceeded"}
        
        # Create workflow execution record
        workflow_execution = WorkflowExecution(
            workflow_id=workflow_id,
            user_prompt=user_prompt,
            status="Running",
            started_at=datetime.utcnow()
        )
        self.db_session.add(workflow_execution)
        self.db_session.commit()
        
        # Get workflow steps in order
        steps = self.db_session.query(WorkflowStep).filter(
            WorkflowStep.workflow_id == workflow_id
        ).order_by(WorkflowStep.step_order).all()
        
        # Execute each step in sequence
        execution_context = {"user_prompt": user_prompt}
        execution_success = True
        
        for step in steps:
            # Get the tool for this step
            tool = self.db_session.query(AITool).filter(AITool.id == step.tool_id).first()
            if not tool or not tool.is_active:
                self._record_step_failure(workflow_execution.id, step.id, "Tool not available")
                execution_success = False
                break
            
            # Create step execution record
            step_execution = StepExecution(
                workflow_execution_id=workflow_execution.id,
                step_id=step.id,
                status="Running",
                started_at=datetime.utcnow(),
                input_data=json.dumps(self._prepare_step_input(step, execution_context))
            )
            self.db_session.add(step_execution)
            self.db_session.commit()
            
            try:
                # Get the tool instance
                tool_instance = self.tool_registry.get(tool.name)
                if not tool_instance:
                    raise ValueError(f"Tool instance for {tool.name} not found in registry")
                
                # Prepare input for the tool
                tool_input = self._prepare_step_input(step, execution_context)
                
                # Execute the tool
                tool_output = self._execute_tool(tool, tool_instance, tool_input)
                
                # Update execution context with tool output
                self._update_execution_context(step, tool_output, execution_context)
                
                # Record API usage
                self._record_api_usage(user.id, tool.id, workflow_execution.id, tool_input, tool_output, tool.cost_per_call)
                
                # Update user's API call count
                user.api_calls_used += 1
                self.db_session.commit()
                
                # Update step execution record
                step_execution.status = "Completed"
                step_execution.completed_at = datetime.utcnow()
                step_execution.output_data = json.dumps(tool_output)
                self.db_session.commit()
                
            except Exception as e:
                logger.error(f"Error executing step {step.id}: {str(e)}")
                step_execution.status = "Failed"
                step_execution.completed_at = datetime.utcnow()
                step_execution.error = str(e)
                self.db_session.commit()
                execution_success = False
                break
        
        # Update workflow execution record
        workflow_execution.status = "Completed" if execution_success else "Failed"
        workflow_execution.completed_at = datetime.utcnow()
        workflow_execution.result = json.dumps(execution_context)
        self.db_session.commit()
        
        return {
            "status": workflow_execution.status,
            "execution_id": workflow_execution.id,
            "results": execution_context
        }
    
    def _prepare_step_input(self, step: WorkflowStep, execution_context: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare input for a workflow step based on the execution context."""
        if not step.input_mapping:
            return {"user_prompt": execution_context.get("user_prompt", "")}
        
        input_mapping = json.loads(step.input_mapping)
        step_input = {}
        
        for target_key, source_path in input_mapping.items():
            # Handle simple key mapping
            if source_path in execution_context:
                step_input[target_key] = execution_context[source_path]
            # Handle nested path with dot notation
            elif "." in source_path:
                parts = source_path.split(".")
                value = execution_context
                for part in parts:
                    if isinstance(value, dict) and part in value:
                        value = value[part]
                    else:
                        value = None
                        break
                if value is not None:
                    step_input[target_key] = value
        
        # Always include user_prompt
        if "user_prompt" not in step_input:
            step_input["user_prompt"] = execution_context.get("user_prompt", "")
            
        return step_input
    
    def _update_execution_context(self, step: WorkflowStep, tool_output: Dict[str, Any], execution_context: Dict[str, Any]) -> None:
        """Update the execution context with the output of a workflow step."""
        if not step.output_mapping:
            # Default behavior: store output under step ID
            execution_context[f"step_{step.id}_output"] = tool_output
            return
        
        output_mapping = json.loads(step.output_mapping)
        for target_key, source_path in output_mapping.items():
            # Handle simple key mapping
            if source_path in tool_output:
                execution_context[target_key] = tool_output[source_path]
            # Handle nested path with dot notation
            elif "." in source_path:
                parts = source_path.split(".")
                value = tool_output
                for part in parts:
                    if isinstance(value, dict) and part in value:
                        value = value[part]
                    else:
                        value = None
                        break
                if value is not None:
                    execution_context[target_key] = value
    
    def _execute_tool(self, tool: AITool, tool_instance: Any, tool_input: Dict[str, Any]) -> Dict[str, Any]:
        """Execute an AI tool with the given input."""
        # This is a simplified implementation
        # In a real system, this would handle different tool types and APIs
        try:
            return tool_instance.execute(tool_input)
        except Exception as e:
            logger.error(f"Error executing tool {tool.name}: {str(e)}")
            raise
    
    def _record_step_failure(self, workflow_execution_id: int, step_id: int, error: str) -> None:
        """Record a step execution failure."""
        step_execution = StepExecution(
            workflow_execution_id=workflow_execution_id,
            step_id=step_id,
            status="Failed",
            started_at=datetime.utcnow(),
            completed_at=datetime.utcnow(),
            error=error
        )
        self.db_session.add(step_execution)
        self.db_session.commit()
    
    def _record_api_usage(self, user_id: int, tool_id: int, workflow_execution_id: int, 
                          request_data: Dict[str, Any], response_data: Dict[str, Any], cost: float) -> None:
        """Record API usage for billing and tracking purposes."""
        api_usage = APIUsage(
            user_id=user_id,
            tool_id=tool_id,
            workflow_execution_id=workflow_execution_id,
            request_data=json.dumps(request_data),
            response_data=json.dumps(response_data),
            cost=cost,
            is_billable=True  # Could be set to False for cached responses
        )
        self.db_session.add(api_usage)
        self.db_session.commit()
