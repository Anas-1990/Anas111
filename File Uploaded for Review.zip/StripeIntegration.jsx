import React, { useState, useEffect } from 'react';
import { useApi } from '../utils/api';

const StripeIntegration = ({ userId, subscriptionTier, onSuccess, onError }) => {
  const { api, loading, error } = useApi();
  const [isProcessing, setIsProcessing] = useState(false);
  const [priceId, setPriceId] = useState('');

  useEffect(() => {
    // Set the appropriate Stripe price ID based on the subscription tier
    switch (subscriptionTier) {
      case 'Basic':
        setPriceId('price_basic_monthly');
        break;
      case 'Pro':
        setPriceId('price_pro_monthly');
        break;
      case 'Enterprise':
        setPriceId('price_enterprise_monthly');
        break;
      default:
        setPriceId('');
    }
  }, [subscriptionTier]);

  const handleSubscribe = async () => {
    if (!priceId) {
      onError && onError('Invalid subscription tier');
      return;
    }

    setIsProcessing(true);
    try {
      // In a real implementation, this would call your backend API to create a Stripe checkout session
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          priceId,
          userId,
          successUrl: window.location.origin + '/dashboard?subscription=success',
          cancelUrl: window.location.origin + '/pricing?subscription=canceled',
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create checkout session');
      }

      const { sessionId } = await response.json();

      // Redirect to Stripe Checkout
      const stripe = window.Stripe(process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY);
      const { error } = await stripe.redirectToCheckout({ sessionId });

      if (error) {
        throw new Error(error.message);
      }
    } catch (err) {
      console.error('Subscription error:', err);
      onError && onError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <button
      type="button"
      className={`block w-full bg-indigo-600 border border-transparent rounded-md py-2 text-sm font-semibold text-white text-center hover:bg-indigo-700 ${
        isProcessing || loading ? 'opacity-50 cursor-not-allowed' : ''
      }`}
      onClick={handleSubscribe}
      disabled={isProcessing || loading || !priceId}
    >
      {isProcessing ? 'Processing...' : 'Subscribe Now'}
    </button>
  );
};

export default StripeIntegration;
