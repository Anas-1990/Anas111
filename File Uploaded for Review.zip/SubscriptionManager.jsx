import React, { useState, useEffect } from 'react';
import { useApi } from '../utils/api';

const SubscriptionManager = ({ userId }) => {
  const { api, loading, error } = useApi();
  const [subscription, setSubscription] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [processingAction, setProcessingAction] = useState(false);
  const [actionError, setActionError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  useEffect(() => {
    const fetchSubscription = async () => {
      try {
        // In a real implementation, this would call your backend API
        const response = await fetch(`/api/subscriptions/${userId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch subscription data');
        }
        const data = await response.json();
        setSubscription(data);
      } catch (err) {
        console.error('Error fetching subscription:', err);
        // For demo purposes, set a mock subscription
        setSubscription({
          id: 'sub_123456',
          status: 'active',
          tier: 'Pro',
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          api_calls_limit: 1000,
          api_calls_used: 342,
          payment_method: {
            brand: 'visa',
            last4: '4242',
            exp_month: 12,
            exp_year: 2025
          }
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchSubscription();
  }, [userId]);

  const handleUpgrade = async (newTier) => {
    setProcessingAction(true);
    setActionError(null);
    setSuccessMessage(null);
    
    try {
      // In a real implementation, this would redirect to a Stripe checkout page
      // For demo purposes, we'll just simulate a successful upgrade
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSubscription(prev => ({
        ...prev,
        tier: newTier,
        api_calls_limit: newTier === 'Pro' ? 1000 : 100,
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      }));
      
      setSuccessMessage(`Successfully upgraded to ${newTier} plan!`);
    } catch (err) {
      console.error('Error upgrading subscription:', err);
      setActionError(err.message || 'Failed to upgrade subscription');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleCancel = async () => {
    setProcessingAction(true);
    setActionError(null);
    setSuccessMessage(null);
    
    try {
      // In a real implementation, this would call your backend API
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSubscription(prev => ({
        ...prev,
        status: 'canceled',
        cancel_at_period_end: true
      }));
      
      setSuccessMessage('Subscription canceled. You will have access until the end of your billing period.');
    } catch (err) {
      console.error('Error canceling subscription:', err);
      setActionError(err.message || 'Failed to cancel subscription');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleUpdatePaymentMethod = async () => {
    setProcessingAction(true);
    setActionError(null);
    setSuccessMessage(null);
    
    try {
      // In a real implementation, this would redirect to a Stripe update page
      // For demo purposes, we'll just simulate a successful update
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSubscription(prev => ({
        ...prev,
        payment_method: {
          brand: 'mastercard',
          last4: '5678',
          exp_month: 3,
          exp_year: 2026
        }
      }));
      
      setSuccessMessage('Payment method updated successfully!');
    } catch (err) {
      console.error('Error updating payment method:', err);
      setActionError(err.message || 'Failed to update payment method');
    } finally {
      setProcessingAction(false);
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
        <div className="animate-pulse flex space-x-4">
          <div className="flex-1 space-y-4 py-1">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
        <p className="text-gray-500">No subscription found. Please select a plan to get started.</p>
      </div>
    );
  }

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
        <div>
          <h3 className="text-lg leading-6 font-medium text-gray-900">Subscription Details</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Manage your subscription and billing information.</p>
        </div>
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          subscription.status === 'active' ? 'bg-green-100 text-green-800' : 
          subscription.status === 'canceled' ? 'bg-red-100 text-red-800' : 
          'bg-yellow-100 text-yellow-800'
        }`}>
          {subscription.status.charAt(0).toUpperCase() + subscription.status.slice(1)}
        </span>
      </div>
      <div className="border-t border-gray-200">
        <dl>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Current Plan</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {subscription.tier}
            </dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Billing Period</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              {subscription.cancel_at_period_end ? 
                `Access until ${new Date(subscription.current_period_end).toLocaleDateString()}` : 
                `Renews on ${new Date(subscription.current_period_end).toLocaleDateString()}`
              }
            </dd>
          </div>
          <div className="bg-gray-50 px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">API Usage</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              <div className="flex items-center">
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-indigo-600 h-2.5 rounded-full" 
                    style={{ width: `${Math.min(100, (subscription.api_calls_used / subscription.api_calls_limit) * 100)}%` }}
                  ></div>
                </div>
                <span className="ml-2 text-xs text-gray-500">
                  {subscription.api_calls_used} / {subscription.api_calls_limit}
                </span>
              </div>
            </dd>
          </div>
          <div className="bg-white px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
            <dt className="text-sm font-medium text-gray-500">Payment Method</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
              <div className="flex items-center">
                <span className="capitalize">{subscription.payment_method.brand}</span>
                <span className="mx-1">•••• {subscription.payment_method.last4}</span>
                <span className="text-gray-500 text-xs">
                  Expires {subscription.payment_method.exp_month}/{subscription.payment_method.exp_year}
                </span>
                <button
                  type="button"
                  className="ml-4 inline-flex items-center px-2.5 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  onClick={handleUpdatePaymentMethod}
                  disabled={processingAction}
                >
                  Update
                </button>
              </div>
            </dd>
          </div>
        </dl>
      </div>
      
      {/* Action buttons */}
      <div className="px-4 py-5 sm:px-6 border-t border-gray-200">
        <div className="flex flex-col sm:flex-row sm:justify-end space-y-3 sm:space-y-0 sm:space-x-3">
          {subscription.tier !== 'Pro' && subscription.status === 'active' && (
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              onClick={() => handleUpgrade('Pro')}
              disabled={processingAction}
            >
              {processingAction ? 'Processing...' : 'Upgrade to Pro'}
            </button>
          )}
          
          {subscription.tier !== 'Basic' && subscription.status === 'active' && (
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              onClick={() => handleUpgrade('Basic')}
              disabled={processingAction}
            >
              {processingAction ? 'Processing...' : 'Downgrade to Basic'}
            </button>
          )}
          
          {subscription.status === 'active' && !subscription.cancel_at_period_end && (
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              onClick={handleCancel}
              disabled={processingAction}
            >
              {processingAction ? 'Processing...' : 'Cancel Subscription'}
            </button>
          )}
        </div>
      </div>
      
      {/* Success/Error messages */}
      {successMessage && (
        <div className="px-4 py-3 sm:px-6 bg-green-50 border-t border-green-200">
          <p className="text-sm text-green-700">{successMessage}</p>
        </div>
      )}
      
      {actionError && (
        <div className="px-4 py-3 sm:px-6 bg-red-50 border-t border-red-200">
          <p className="text-sm text-red-700">{actionError}</p>
        </div>
      )}
    </div>
  );
};

export default SubscriptionManager;
