import pytest
from unittest.mock import MagicMock, patch
import sys
import os

# Add the src directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.api_integrations.tools import ChatGPTTool, ElevenLabsTool, HashtagGeneratorTool

class TestAITools:
    @pytest.fixture
    def mock_openai(self):
        with patch('src.api_integrations.tools.openai') as mock:
            mock.ChatCompletion.create.return_value = {
                "choices": [
                    {
                        "message": {
                            "content": "This is a test response from ChatGPT"
                        }
                    }
                ],
                "usage": {
                    "total_tokens": 50
                }
            }
            yield mock
    
    @pytest.fixture
    def mock_elevenlabs(self):
        with patch('src.api_integrations.tools.requests') as mock:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b"audio_data"
            mock_response.json.return_value = {
                "audio_url": "https://api.elevenlabs.io/audio/123456.mp3"
            }
            mock.post.return_value = mock_response
            yield mock
    
    def test_chatgpt_tool_execute(self, mock_openai):
        # Create ChatGPT tool
        tool = ChatGPTTool(api_key="test_key")
        
        # Execute tool
        result = tool.execute({
            "prompt": "Write a test message",
            "model": "gpt-4",
            "temperature": 0.7,
            "max_tokens": 100
        })
        
        # Verify OpenAI API was called correctly
        mock_openai.ChatCompletion.create.assert_called_once_with(
            model="gpt-4",
            messages=[{"role": "user", "content": "Write a test message"}],
            temperature=0.7,
            max_tokens=100
        )
        
        # Verify result
        assert "text" in result
        assert result["text"] == "This is a test response from ChatGPT"
        assert "usage" in result
        assert result["usage"]["total_tokens"] == 50
        assert "model" in result
        assert result["model"] == "gpt-4"
    
    def test_elevenlabs_tool_execute(self, mock_elevenlabs):
        # Create ElevenLabs tool
        tool = ElevenLabsTool(api_key="test_key")
        
        # Execute tool
        result = tool.execute({
            "text": "This is a test for text to speech",
            "voice_id": "test_voice",
            "model_id": "eleven_monolingual_v1"
        })
        
        # Verify ElevenLabs API was called correctly
        mock_elevenlabs.post.assert_called_once()
        args, kwargs = mock_elevenlabs.post.call_args
        assert args[0].endswith("/text-to-speech/test_voice")
        assert kwargs["json"]["text"] == "This is a test for text to speech"
        assert kwargs["json"]["model_id"] == "eleven_monolingual_v1"
        
        # Verify result
        assert "audio_url" in result
        assert result["audio_url"] == "https://api.elevenlabs.io/audio/123456.mp3"
        assert "voice_id" in result
        assert result["voice_id"] == "test_voice"
        assert "text_length" in result
    
    def test_hashtag_generator_tool_execute(self):
        # Create HashtagGenerator tool
        tool = HashtagGeneratorTool()
        
        # Mock the internal _generate_hashtags method
        tool._generate_hashtags = MagicMock(return_value=[
            "#AI", "#ContentCreation", "#Influencer", "#SocialMedia", "#Marketing"
        ])
        
        # Execute tool
        result = tool.execute({
            "content": "This is a post about AI tools for content creators",
            "platform": "instagram",
            "count": 5
        })
        
        # Verify _generate_hashtags was called correctly
        tool._generate_hashtags.assert_called_once_with(
            "This is a post about AI tools for content creators",
            "instagram",
            5
        )
        
        # Verify result
        assert "hashtags" in result
        assert len(result["hashtags"]) == 5
        assert "#AI" in result["hashtags"]
        assert "platform" in result
        assert result["platform"] == "instagram"
        assert "count" in result
        assert result["count"] == 5
