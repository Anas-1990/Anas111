import React, { useState } from 'react';
import { useApi } from '../utils/api';

const BillingHistoryComponent = ({ userId }) => {
  const { api, loading, error } = useApi();
  const [billingHistory, setBillingHistory] = useState([
    {
      id: 'inv_123456',
      date: '2025-04-01',
      amount: 29.99,
      status: 'paid',
      description: 'Pro Plan - Monthly Subscription',
      pdf: '/invoices/inv_123456.pdf'
    },
    {
      id: 'inv_123455',
      date: '2025-03-01',
      amount: 29.99,
      status: 'paid',
      description: 'Pro Plan - Monthly Subscription',
      pdf: '/invoices/inv_123455.pdf'
    },
    {
      id: 'inv_123454',
      date: '2025-02-01',
      amount: 29.99,
      status: 'paid',
      description: 'Pro Plan - Monthly Subscription',
      pdf: '/invoices/inv_123454.pdf'
    },
    {
      id: 'inv_123453',
      date: '2025-01-01',
      amount: 9.99,
      status: 'paid',
      description: 'Basic Plan - Monthly Subscription',
      pdf: '/invoices/inv_123453.pdf'
    }
  ]);

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Billing History</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">View and download your past invoices.</p>
      </div>
      <div className="border-t border-gray-200">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Invoice
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {billingHistory.map((invoice) => (
                <tr key={invoice.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(invoice.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {invoice.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${invoice.amount.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      invoice.status === 'paid' ? 'bg-green-100 text-green-800' : 
                      invoice.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'
                    }`}>
                      {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <a href={invoice.pdf} className="text-indigo-600 hover:text-indigo-900">
                      Download
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BillingHistoryComponent;
