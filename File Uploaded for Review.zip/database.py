from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Table, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
import datetime

Base = declarative_base()

# Association table for many-to-many relationship between users and tools
user_tool_association = Table(
    'user_tool_association',
    Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id')),
    Column('tool_id', Integer, ForeignKey('ai_tools.id'))
)

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    first_name = Column(String)
    last_name = Column(String)
    subscription_tier = Column(String, default='Basic')  # Basic, Pro, Enterprise
    subscription_status = Column(String, default='Active')  # Active, Inactive, Trial
    trial_end_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    api_calls_limit = Column(Integer)
    api_calls_used = Column(Integer, default=0)
    is_enterprise = Column(Boolean, default=False)
    has_2fa = Column(Boolean, default=False)
    
    # Relationships
    workflows = relationship("Workflow", back_populates="user")
    api_usages = relationship("APIUsage", back_populates="user")
    payments = relationship("Payment", back_populates="user")
    tools = relationship("AITool", secondary=user_tool_association)

class AITool(Base):
    __tablename__ = 'ai_tools'
    
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String)
    api_key_name = Column(String)  # Name of the environment variable storing the API key
    base_url = Column(String)
    category = Column(String)  # Content Creation, Social Media, SEO & Monetization
    cost_per_call = Column(Float)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    # Relationships
    api_usages = relationship("APIUsage", back_populates="tool")
    workflow_steps = relationship("WorkflowStep", back_populates="tool")

class Workflow(Base):
    __tablename__ = 'workflows'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    name = Column(String, nullable=False)
    description = Column(String)
    is_template = Column(Boolean, default=False)
    template_category = Column(String)  # TikTok Viral Video, Blog-to-Thread, Podcast Clip Generator
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="workflows")
    steps = relationship("WorkflowStep", back_populates="workflow")
    executions = relationship("WorkflowExecution", back_populates="workflow")

class WorkflowStep(Base):
    __tablename__ = 'workflow_steps'
    
    id = Column(Integer, primary_key=True)
    workflow_id = Column(Integer, ForeignKey('workflows.id'))
    tool_id = Column(Integer, ForeignKey('ai_tools.id'))
    step_order = Column(Integer, nullable=False)
    input_mapping = Column(String)  # JSON string mapping inputs from previous steps
    output_mapping = Column(String)  # JSON string mapping outputs to variables
    config = Column(String)  # JSON string with step-specific configuration
    
    # Relationships
    workflow = relationship("Workflow", back_populates="steps")
    tool = relationship("AITool", back_populates="workflow_steps")

class WorkflowExecution(Base):
    __tablename__ = 'workflow_executions'
    
    id = Column(Integer, primary_key=True)
    workflow_id = Column(Integer, ForeignKey('workflows.id'))
    user_prompt = Column(String)
    status = Column(String)  # Pending, Running, Completed, Failed
    started_at = Column(DateTime, default=datetime.datetime.utcnow)
    completed_at = Column(DateTime)
    result = Column(String)  # JSON string with execution results
    
    # Relationships
    workflow = relationship("Workflow", back_populates="executions")
    step_executions = relationship("StepExecution", back_populates="workflow_execution")

class StepExecution(Base):
    __tablename__ = 'step_executions'
    
    id = Column(Integer, primary_key=True)
    workflow_execution_id = Column(Integer, ForeignKey('workflow_executions.id'))
    step_id = Column(Integer, ForeignKey('workflow_steps.id'))
    status = Column(String)  # Pending, Running, Completed, Failed
    started_at = Column(DateTime, default=datetime.datetime.utcnow)
    completed_at = Column(DateTime)
    input_data = Column(String)  # JSON string with input data
    output_data = Column(String)  # JSON string with output data
    error = Column(String)
    
    # Relationships
    workflow_execution = relationship("WorkflowExecution", back_populates="step_executions")

class APIUsage(Base):
    __tablename__ = 'api_usages'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    tool_id = Column(Integer, ForeignKey('ai_tools.id'))
    workflow_execution_id = Column(Integer, ForeignKey('workflow_executions.id'), nullable=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    request_data = Column(String)  # JSON string with request data
    response_data = Column(String)  # JSON string with response data
    cost = Column(Float)
    is_billable = Column(Boolean, default=True)  # False for cached responses
    
    # Relationships
    user = relationship("User", back_populates="api_usages")
    tool = relationship("AITool", back_populates="api_usages")

class Payment(Base):
    __tablename__ = 'payments'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    amount = Column(Float, nullable=False)
    currency = Column(String, default='USD')
    payment_method = Column(String)  # Credit Card, PayPal, etc.
    payment_status = Column(String)  # Pending, Completed, Failed
    stripe_payment_id = Column(String)
    payment_date = Column(DateTime, default=datetime.datetime.utcnow)
    subscription_period_start = Column(DateTime)
    subscription_period_end = Column(DateTime)
    is_recurring = Column(Boolean, default=True)
    
    # Relationships
    user = relationship("User", back_populates="payments")

# Database connection and session creation
def get_engine(database_url="postgresql://postgres:postgres@localhost/ai_tool_aggregator"):
    return create_engine(database_url)

def get_session(engine):
    Session = sessionmaker(bind=engine)
    return Session()

def init_db(engine):
    Base.metadata.create_all(engine)
