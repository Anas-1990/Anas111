import React, { useState } from 'react';
import { useApi } from '../utils/api';

const WorkflowExecutionComponent = ({ workflowId, userId }) => {
  const { api, loading, error } = useApi();
  const [userPrompt, setUserPrompt] = useState('');
  const [executionResult, setExecutionResult] = useState(null);
  const [executionId, setExecutionId] = useState(null);
  const [executionStatus, setExecutionStatus] = useState(null);
  const [isExecuting, setIsExecuting] = useState(false);

  const executeWorkflow = async () => {
    if (!userPrompt.trim()) {
      alert('Please enter a prompt for the workflow');
      return;
    }

    setIsExecuting(true);
    setExecutionStatus('Starting workflow execution...');

    try {
      // Execute the workflow
      const result = await api.workflows.execute(workflowId, userPrompt);
      
      setExecutionId(result.execution_id);
      setExecutionStatus(`Workflow execution ${result.status.toLowerCase()}`);
      
      // If the execution is completed immediately, set the result
      if (result.status === 'Completed') {
        setExecutionResult(result.results);
      } else {
        // Otherwise, poll for the result
        pollExecutionResult(result.execution_id);
      }
    } catch (err) {
      setExecutionStatus(`Error: ${err.message}`);
      console.error('Workflow execution error:', err);
    }
  };

  const pollExecutionResult = async (execId) => {
    try {
      // Poll every 2 seconds until the execution is complete
      const intervalId = setInterval(async () => {
        const result = await api.workflows.getExecutionResult(execId);
        
        if (result.status === 'Completed' || result.status === 'Failed') {
          clearInterval(intervalId);
          setExecutionStatus(`Workflow execution ${result.status.toLowerCase()}`);
          setExecutionResult(result.result);
          setIsExecuting(false);
        }
      }, 2000);
      
      // Clear interval after 5 minutes (timeout)
      setTimeout(() => {
        clearInterval(intervalId);
        if (isExecuting) {
          setExecutionStatus('Execution timed out');
          setIsExecuting(false);
        }
      }, 5 * 60 * 1000);
    } catch (err) {
      setExecutionStatus(`Error polling result: ${err.message}`);
      setIsExecuting(false);
      console.error('Error polling execution result:', err);
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Workflow Execution</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">
          Enter a prompt to execute this workflow
        </p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        <div className="mb-4">
          <label htmlFor="user_prompt" className="block text-sm font-medium text-gray-700">
            Your Prompt
          </label>
          <div className="mt-1">
            <textarea
              id="user_prompt"
              name="user_prompt"
              rows={3}
              className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
              placeholder="e.g., Create a TikTok video about AI tools for content creators"
              value={userPrompt}
              onChange={(e) => setUserPrompt(e.target.value)}
              disabled={isExecuting}
            />
          </div>
        </div>
        
        <div className="flex justify-end">
          <button
            type="button"
            className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
              isExecuting ? 'bg-gray-400' : 'bg-indigo-600 hover:bg-indigo-700'
            } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
            onClick={executeWorkflow}
            disabled={isExecuting}
          >
            {isExecuting ? 'Executing...' : 'Execute Workflow'}
          </button>
        </div>
        
        {executionStatus && (
          <div className="mt-4 p-4 rounded-md bg-gray-50">
            <p className="text-sm font-medium text-gray-900">Status: {executionStatus}</p>
            {executionId && (
              <p className="mt-1 text-sm text-gray-500">Execution ID: {executionId}</p>
            )}
          </div>
        )}
        
        {executionResult && (
          <div className="mt-6">
            <h4 className="text-lg font-medium text-gray-900">Execution Result</h4>
            <div className="mt-2 border border-gray-200 rounded-md p-4 bg-gray-50 overflow-auto max-h-96">
              <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                {JSON.stringify(executionResult, null, 2)}
              </pre>
            </div>
          </div>
        )}
        
        {error && (
          <div className="mt-4 p-4 rounded-md bg-red-50">
            <p className="text-sm font-medium text-red-800">Error: {error}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkflowExecutionComponent;
