import { useState, useEffect } from 'react';

// Custom hook for API calls
export const useApi = () => {
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Generic fetch function with error handling
  const fetchData = async (endpoint, options = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `API error: ${response.status}`);
      }

      const data = await response.json();
      setLoading(false);
      return data;
    } catch (err) {
      setError(err.message);
      setLoading(false);
      throw err;
    }
  };

  // API methods for different resources
  const api = {
    // User related endpoints
    users: {
      create: (userData) => fetchData('/users/', {
        method: 'POST',
        body: JSON.stringify(userData),
      }),
      getCurrentUser: () => fetchData('/users/me'),
      updateUser: (userId, userData) => fetchData(`/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify(userData),
      }),
    },

    // Workflow related endpoints
    workflows: {
      list: (params = {}) => {
        const queryParams = new URLSearchParams();
        if (params.userId) queryParams.append('user_id', params.userId);
        if (params.isTemplate !== undefined) queryParams.append('is_template', params.isTemplate);
        if (params.templateCategory) queryParams.append('template_category', params.templateCategory);
        
        const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
        return fetchData(`/workflows/${queryString}`);
      },
      get: (workflowId) => fetchData(`/workflows/${workflowId}`),
      create: (workflowData) => fetchData('/workflows/', {
        method: 'POST',
        body: JSON.stringify(workflowData),
      }),
      addStep: (workflowId, stepData) => fetchData(`/workflows/${workflowId}/steps/`, {
        method: 'POST',
        body: JSON.stringify(stepData),
      }),
      execute: (workflowId, userPrompt) => fetchData(`/workflows/${workflowId}/execute`, {
        method: 'POST',
        body: JSON.stringify({ user_prompt: userPrompt }),
      }),
      getExecutionResult: (executionId) => fetchData(`/executions/${executionId}`),
    },

    // AI Tools related endpoints
    tools: {
      list: () => fetchData('/tools/'),
      executeChatGPT: (inputData) => fetchData('/tools/chatgpt/execute', {
        method: 'POST',
        body: JSON.stringify(inputData),
      }),
      executeElevenLabs: (inputData) => fetchData('/tools/elevenlabs/execute', {
        method: 'POST',
        body: JSON.stringify(inputData),
      }),
      executeHashtagGenerator: (inputData) => fetchData('/tools/hashtag-generator/execute', {
        method: 'POST',
        body: JSON.stringify(inputData),
      }),
    },
  };

  return { api, loading, error };
};

// Authentication context
export const useAuth = () => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const { api } = useApi();

  useEffect(() => {
    // Check if user is logged in on component mount
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('auth_token');
        if (token) {
          // Fetch current user data
          const userData = await api.users.getCurrentUser();
          setUser(userData);
          setIsAuthenticated(true);
        }
      } catch (error) {
        console.error('Authentication error:', error);
        localStorage.removeItem('auth_token');
      } finally {
        setAuthLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email, password) => {
    setAuthLoading(true);
    try {
      // This is a simplified login implementation
      // In a real app, you would call an API endpoint to get a token
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        throw new Error('Login failed');
      }

      const { token, user } = await response.json();
      localStorage.setItem('auth_token', token);
      setUser(user);
      setIsAuthenticated(true);
      return user;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setAuthLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('auth_token');
    setUser(null);
    setIsAuthenticated(false);
  };

  const register = async (userData) => {
    setAuthLoading(true);
    try {
      const newUser = await api.users.create(userData);
      // After registration, log the user in
      await login(userData.email, userData.password);
      return newUser;
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    } finally {
      setAuthLoading(false);
    }
  };

  return {
    user,
    isAuthenticated,
    authLoading,
    login,
    logout,
    register,
  };
};

// Subscription management hook
export const useSubscription = () => {
  const { api } = useApi();
  const { user } = useAuth();
  const [subscription, setSubscription] = useState(null);
  const [subscriptionLoading, setSubscriptionLoading] = useState(true);

  useEffect(() => {
    if (user) {
      // Fetch user's subscription details
      const fetchSubscription = async () => {
        try {
          // In a real app, you would call an API endpoint to get subscription details
          // For now, we'll use the user's subscription_tier
          setSubscription({
            tier: user.subscription_tier,
            status: user.subscription_status,
            apiCallsLimit: user.api_calls_limit,
            apiCallsUsed: user.api_calls_used,
            renewalDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
          });
        } catch (error) {
          console.error('Error fetching subscription:', error);
        } finally {
          setSubscriptionLoading(false);
        }
      };

      fetchSubscription();
    }
  }, [user]);

  const upgradePlan = async (newTier) => {
    // In a real app, this would redirect to Stripe or another payment processor
    console.log(`Upgrading to ${newTier} plan`);
    // Mock implementation for demo purposes
    return { success: true, message: `Upgraded to ${newTier} plan` };
  };

  const cancelSubscription = async () => {
    // In a real app, this would call an API to cancel the subscription
    console.log('Cancelling subscription');
    // Mock implementation for demo purposes
    return { success: true, message: 'Subscription cancelled' };
  };

  return {
    subscription,
    subscriptionLoading,
    upgradePlan,
    cancelSubscription,
  };
};
