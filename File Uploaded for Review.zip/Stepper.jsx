import React from 'react';
import { FiArrowLeft, FiArrowRight } from 'react-icons/fi';

const Stepper = ({
  steps,
  currentStep,
  onStepChange,
  orientation = 'horizontal',
  size = 'md',
  className = '',
}) => {
  // Size classes
  const sizeClasses = {
    sm: {
      container: 'text-xs',
      step: 'h-6 w-6',
      line: 'h-0.5'
    },
    md: {
      container: 'text-sm',
      step: 'h-8 w-8',
      line: 'h-0.5'
    },
    lg: {
      container: 'text-base',
      step: 'h-10 w-10',
      line: 'h-1'
    }
  };

  const selectedSize = sizeClasses[size] || sizeClasses.md;

  // Handle step click
  const handleStepClick = (index) => {
    if (onStepChange && index <= Math.max(...steps.map(step => step.completed ? steps.indexOf(step) + 1 : 0))) {
      onStepChange(index);
    }
  };

  return (
    <div className={`${className} ${orientation === 'vertical' ? 'flex' : ''}`}>
      <nav aria-label="Progress" className={selectedSize.container}>
        {orientation === 'horizontal' ? (
          <ol className="flex items-center">
            {steps.map((step, index) => {
              const isActive = index + 1 === currentStep;
              const isCompleted = step.completed;
              const isClickable = onStepChange && (isCompleted || index <= Math.max(...steps.map(s => s.completed ? steps.indexOf(s) + 1 : 0)));

              return (
                <li key={step.id} className={`relative ${index !== 0 ? 'pl-6 sm:pl-8' : ''} ${index !== steps.length - 1 ? 'pr-6 sm:pr-8' : ''} flex-1`}>
                  {index !== 0 && (
                    <div className={`absolute inset-0 flex items-center`} aria-hidden="true">
                      <div className={`h-0.5 w-full ${isCompleted ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
                    </div>
                  )}
                  <div 
                    className={`relative flex items-center justify-center ${isClickable ? 'cursor-pointer' : ''}`}
                    onClick={() => isClickable && handleStepClick(index + 1)}
                  >
                    {isCompleted ? (
                      <span className={`${selectedSize.step} flex items-center justify-center bg-indigo-600 rounded-full`}>
                        <svg className="w-5 h-5 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </span>
                    ) : isActive ? (
                      <span className={`${selectedSize.step} flex items-center justify-center bg-white border-2 border-indigo-600 rounded-full`}>
                        <span className="text-indigo-600">{index + 1}</span>
                      </span>
                    ) : (
                      <span className={`${selectedSize.step} flex items-center justify-center bg-white border-2 border-gray-300 rounded-full`}>
                        <span className="text-gray-500">{index + 1}</span>
                      </span>
                    )}
                    <span className={`absolute top-10 text-center w-max -left-1/2 right-0 mx-auto ${isActive ? 'text-indigo-600 font-medium' : isCompleted ? 'text-indigo-600' : 'text-gray-500'}`}>
                      {step.name}
                    </span>
                  </div>
                </li>
              );
            })}
          </ol>
        ) : (
          <ol className="space-y-6">
            {steps.map((step, index) => {
              const isActive = index + 1 === currentStep;
              const isCompleted = step.completed;
              const isClickable = onStepChange && (isCompleted || index <= Math.max(...steps.map(s => s.completed ? steps.indexOf(s) + 1 : 0)));

              return (
                <li key={step.id} className="relative flex items-start">
                  <div 
                    className={`flex items-center ${isClickable ? 'cursor-pointer' : ''}`}
                    onClick={() => isClickable && handleStepClick(index + 1)}
                  >
                    {isCompleted ? (
                      <span className={`${selectedSize.step} flex items-center justify-center bg-indigo-600 rounded-full`}>
                        <svg className="w-5 h-5 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </span>
                    ) : isActive ? (
                      <span className={`${selectedSize.step} flex items-center justify-center bg-white border-2 border-indigo-600 rounded-full`}>
                        <span className="text-indigo-600">{index + 1}</span>
                      </span>
                    ) : (
                      <span className={`${selectedSize.step} flex items-center justify-center bg-white border-2 border-gray-300 rounded-full`}>
                        <span className="text-gray-500">{index + 1}</span>
                      </span>
                    )}
                  </div>
                  <div className="ml-4 min-w-0">
                    <span className={`text-sm font-medium ${isActive ? 'text-indigo-600' : isCompleted ? 'text-indigo-600' : 'text-gray-500'}`}>
                      {step.name}
                    </span>
                    {step.description && (
                      <p className="text-sm text-gray-500">{step.description}</p>
                    )}
                  </div>
                </li>
              );
            })}
          </ol>
        )}
      </nav>

      {/* Navigation buttons */}
      {onStepChange && (
        <div className={`flex ${orientation === 'horizontal' ? 'justify-between mt-8' : 'flex-col mt-4'}`}>
          <button
            type="button"
            onClick={() => currentStep > 1 && onStepChange(currentStep - 1)}
            disabled={currentStep <= 1}
            className={`inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
              currentStep <= 1 ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            <FiArrowLeft className="-ml-0.5 mr-2 h-4 w-4" /> Previous
          </button>
          <button
            type="button"
            onClick={() => currentStep < steps.length && onStepChange(currentStep + 1)}
            disabled={currentStep >= steps.length}
            className={`inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
              orientation === 'horizontal' ? '' : 'mt-2'
            } ${currentStep >= steps.length ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            Next <FiArrowRight className="ml-2 -mr-0.5 h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
};

export default Stepper;
