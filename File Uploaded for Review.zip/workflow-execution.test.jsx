import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import WorkflowExecution from '../app/components/WorkflowExecution';
import { useApi } from '../app/utils/api';

// Mock the API hook
jest.mock('../app/utils/api', () => ({
  useApi: jest.fn(),
}));

describe('WorkflowExecution', () => {
  const mockWorkflowId = 'workflow123';
  const mockUserId = 'user123';
  
  beforeEach(() => {
    // Setup default mock implementation
    useApi.mockReturnValue({
      api: {
        workflows: {
          execute: jest.fn().mockResolvedValue({
            execution_id: 'exec_123',
            status: 'Processing'
          }),
          getExecutionResult: jest.fn().mockResolvedValue({
            status: 'Completed',
            result: {
              step1: 'Output from step 1',
              step2: 'Output from step 2',
              final: 'Final workflow result'
            }
          })
        }
      },
      loading: false,
      error: null
    });
  });

  test('renders workflow execution form correctly', () => {
    render(<WorkflowExecution workflowId={mockWorkflowId} userId={mockUserId} />);
    
    expect(screen.getByText('Workflow Execution')).toBeInTheDocument();
    expect(screen.getByText('Enter a prompt to execute this workflow')).toBeInTheDocument();
    expect(screen.getByLabelText('Your Prompt')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Execute Workflow' })).toBeInTheDocument();
  });

  test('handles workflow execution with polling', async () => {
    // Mock API responses for execution and polling
    const mockExecute = jest.fn().mockResolvedValue({
      execution_id: 'exec_123',
      status: 'Processing'
    });
    
    // First poll returns processing, second returns completed
    const mockGetResult = jest.fn()
      .mockResolvedValueOnce({
        status: 'Processing',
        progress: 50
      })
      .mockResolvedValueOnce({
        status: 'Completed',
        result: {
          step1: 'Output from step 1',
          step2: 'Output from step 2',
          final: 'Final workflow result'
        }
      });
    
    useApi.mockReturnValue({
      api: {
        workflows: {
          execute: mockExecute,
          getExecutionResult: mockGetResult
        }
      },
      loading: false,
      error: null
    });

    // Mock timers for polling
    jest.useFakeTimers();
    
    render(<WorkflowExecution workflowId={mockWorkflowId} userId={mockUserId} />);
    
    // Enter prompt
    fireEvent.change(screen.getByLabelText('Your Prompt'), {
      target: { value: 'Create a TikTok video about AI tools' }
    });
    
    // Click execute button
    fireEvent.click(screen.getByRole('button', { name: 'Execute Workflow' }));
    
    // Check if API was called with correct parameters
    expect(mockExecute).toHaveBeenCalledWith(
      mockWorkflowId,
      'Create a TikTok video about AI tools'
    );
    
    // Check status update
    await waitFor(() => {
      expect(screen.getByText(/Starting workflow execution/)).toBeInTheDocument();
    });
    
    // Advance timers to trigger first poll
    jest.advanceTimersByTime(2000);
    
    // Check if polling API was called
    expect(mockGetResult).toHaveBeenCalledWith('exec_123');
    
    // Check status update after first poll
    await waitFor(() => {
      expect(screen.getByText(/50%/)).toBeInTheDocument();
    });
    
    // Advance timers to trigger second poll
    jest.advanceTimersByTime(2000);
    
    // Check if polling API was called again
    expect(mockGetResult).toHaveBeenCalledTimes(2);
    
    // Check for completed status and results
    await waitFor(() => {
      expect(screen.getByText(/Workflow execution completed/)).toBeInTheDocument();
      expect(screen.getByText(/Final workflow result/)).toBeInTheDocument();
    });
    
    // Restore real timers
    jest.useRealTimers();
  });

  test('handles execution errors', async () => {
    // Mock API error
    useApi.mockReturnValue({
      api: {
        workflows: {
          execute: jest.fn().mockRejectedValue(new Error('Workflow execution failed'))
        }
      },
      loading: false,
      error: null
    });
    
    render(<WorkflowExecution workflowId={mockWorkflowId} userId={mockUserId} />);
    
    // Enter prompt
    fireEvent.change(screen.getByLabelText('Your Prompt'), {
      target: { value: 'Create a TikTok video about AI tools' }
    });
    
    // Click execute button
    fireEvent.click(screen.getByRole('button', { name: 'Execute Workflow' }));
    
    // Check for error message
    await waitFor(() => {
      expect(screen.getByText(/Error: Workflow execution failed/)).toBeInTheDocument();
    });
  });

  test('validates empty prompt', async () => {
    render(<WorkflowExecution workflowId={mockWorkflowId} userId={mockUserId} />);
    
    // Click execute button without entering prompt
    fireEvent.click(screen.getByRole('button', { name: 'Execute Workflow' }));
    
    // Check for validation message
    await waitFor(() => {
      expect(screen.getByText(/Please enter a prompt for the workflow/)).toBeInTheDocument();
    });
    
    // API should not be called
    expect(useApi().api.workflows.execute).not.toHaveBeenCalled();
  });

  test('disables form during execution', async () => {
    render(<WorkflowExecution workflowId={mockWorkflowId} userId={mockUserId} />);
    
    // Enter prompt
    fireEvent.change(screen.getByLabelText('Your Prompt'), {
      target: { value: 'Create a TikTok video about AI tools' }
    });
    
    // Click execute button
    fireEvent.click(screen.getByRole('button', { name: 'Execute Workflow' }));
    
    // Check if input and button are disabled
    await waitFor(() => {
      expect(screen.getByLabelText('Your Prompt')).toBeDisabled();
      expect(screen.getByRole('button', { name: 'Executing...' })).toBeDisabled();
    });
  });
});
