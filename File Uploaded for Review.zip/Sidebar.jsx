import React from 'react';
import { FiHome, FiGrid, FiSettings, FiUser, FiCreditCard, FiBarChart2, FiHelpCircle, FiLogOut } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';

const Sidebar = () => {
  const { currentUser, logout } = useAuth();
  
  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: FiHome, current: true },
    { name: 'Workflows', href: '/workflows', icon: FiGrid, current: false },
    { name: 'Analytics', href: '/analytics', icon: FiBarChart2, current: false },
    { name: 'Account', href: '/account', icon: FiUser, current: false },
    { name: 'Billing', href: '/billing', icon: FiCreditCard, current: false },
    { name: 'Settings', href: '/settings', icon: FiSettings, current: false },
    { name: 'Help & Support', href: '/support', icon: FiHelpCircle, current: false },
  ];

  return (
    <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
      <div className="flex-1 flex flex-col min-h-0 bg-indigo-700">
        <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
          <div className="flex items-center flex-shrink-0 px-4">
            <img
              className="h-8 w-auto"
              src="/logo-white.svg"
              alt="AI Tool Aggregator"
            />
            <span className="ml-2 text-white font-semibold text-lg">AI Tool Hub</span>
          </div>
          <nav className="mt-5 flex-1 px-2 space-y-1">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`
                  group flex items-center px-2 py-2 text-sm font-medium rounded-md
                  ${item.current
                    ? 'bg-indigo-800 text-white'
                    : 'text-indigo-100 hover:bg-indigo-600 hover:text-white'
                  }
                `}
              >
                <item.icon
                  className={`
                    mr-3 flex-shrink-0 h-6 w-6
                    ${item.current ? 'text-white' : 'text-indigo-300 group-hover:text-white'}
                  `}
                  aria-hidden="true"
                />
                {item.name}
              </a>
            ))}
          </nav>
        </div>
        <div className="flex-shrink-0 flex border-t border-indigo-800 p-4">
          <div className="flex-shrink-0 w-full group block">
            <div className="flex items-center">
              <div>
                {currentUser?.photoURL ? (
                  <img
                    className="inline-block h-9 w-9 rounded-full"
                    src={currentUser.photoURL}
                    alt=""
                  />
                ) : (
                  <div className="inline-flex h-9 w-9 rounded-full bg-indigo-500 items-center justify-center">
                    <span className="text-white font-medium text-sm">
                      {currentUser?.displayName?.charAt(0) || currentUser?.email?.charAt(0) || 'U'}
                    </span>
                  </div>
                )}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">
                  {currentUser?.displayName || currentUser?.email || 'User'}
                </p>
                <button
                  onClick={logout}
                  className="text-xs font-medium text-indigo-200 group-hover:text-white flex items-center"
                >
                  <FiLogOut className="mr-1 h-3 w-3" />
                  Sign out
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
