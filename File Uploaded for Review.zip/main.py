from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import os
import logging
from typing import List, Dict, Any, Optional
from pydantic import BaseModel

from ..models.database import get_engine, get_session, init_db
from ..orchestration.engine import OrchestrationEngine
from ..workflows.workflow_manager import WorkflowManager
from ..api_integrations.tools import (
    ChatGPTIntegration, 
    ElevenLabsIntegration, 
    BufferIntegration,
    HashtagGenerator,
    SponsorMatcher
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize database
engine = get_engine()
init_db(engine)

# Initialize API integrations
chatgpt_integration = ChatGPTIntegration()
elevenlabs_integration = ElevenLabsIntegration()
buffer_integration = BufferIntegration()
hashtag_generator = HashtagGenerator()
sponsor_matcher = SponsorMatcher()

# Initialize orchestration engine
orchestration_engine = OrchestrationEngine(get_session(engine))

# Register tools with orchestration engine
orchestration_engine.register_tool("ChatGPT", chatgpt_integration)
orchestration_engine.register_tool("ElevenLabs", elevenlabs_integration)
orchestration_engine.register_tool("Buffer", buffer_integration)
orchestration_engine.register_tool("HashtagGenerator", hashtag_generator)
orchestration_engine.register_tool("SponsorMatcher", sponsor_matcher)

# Initialize workflow manager
workflow_manager = WorkflowManager(get_session(engine), orchestration_engine)

# Create FastAPI app
app = FastAPI(
    title="AI Tool Aggregator API",
    description="API for the AI Tool Aggregator Platform for Influencers",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, this should be restricted
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency to get database session
def get_db():
    db = get_session(engine)
    try:
        yield db
    finally:
        db.close()

# Pydantic models for request/response
class WorkflowCreate(BaseModel):
    name: str
    description: str
    is_template: bool = False
    template_category: Optional[str] = None

class WorkflowStepCreate(BaseModel):
    tool_id: int
    step_order: int
    input_mapping: Optional[Dict[str, str]] = None
    output_mapping: Optional[Dict[str, str]] = None
    config: Optional[Dict[str, Any]] = None

class WorkflowExecute(BaseModel):
    user_prompt: str

class UserCreate(BaseModel):
    email: str
    password: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    subscription_tier: str = "Basic"

# API routes
@app.get("/")
def read_root():
    return {"message": "Welcome to the AI Tool Aggregator API"}

# User routes
@app.post("/users/", status_code=status.HTTP_201_CREATED)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    # This is a simplified implementation
    # In a real system, we would hash the password and check for existing users
    from ..models.database import User
    
    db_user = User(
        email=user.email,
        password_hash=user.password,  # In reality, this would be hashed
        first_name=user.first_name,
        last_name=user.last_name,
        subscription_tier=user.subscription_tier,
        api_calls_limit=100 if user.subscription_tier == "Basic" else 1000
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    return {
        "id": db_user.id,
        "email": db_user.email,
        "subscription_tier": db_user.subscription_tier
    }

# Workflow routes
@app.post("/workflows/", status_code=status.HTTP_201_CREATED)
def create_workflow(workflow: WorkflowCreate, user_id: int, db: Session = Depends(get_db)):
    workflow_id = workflow_manager.create_workflow(
        user_id=user_id,
        name=workflow.name,
        description=workflow.description,
        is_template=workflow.is_template,
        template_category=workflow.template_category
    )
    
    return {"id": workflow_id}

@app.post("/workflows/{workflow_id}/steps/", status_code=status.HTTP_201_CREATED)
def add_workflow_step(workflow_id: int, step: WorkflowStepCreate, db: Session = Depends(get_db)):
    step_id = workflow_manager.add_workflow_step(
        workflow_id=workflow_id,
        tool_id=step.tool_id,
        step_order=step.step_order,
        input_mapping=step.input_mapping,
        output_mapping=step.output_mapping,
        config=step.config
    )
    
    return {"id": step_id}

@app.get("/workflows/")
def list_workflows(user_id: Optional[int] = None, is_template: Optional[bool] = None, 
                  template_category: Optional[str] = None, db: Session = Depends(get_db)):
    workflows = workflow_manager.list_workflows(
        user_id=user_id,
        is_template=is_template,
        template_category=template_category
    )
    
    return {"workflows": workflows}

@app.get("/workflows/{workflow_id}")
def get_workflow(workflow_id: int, db: Session = Depends(get_db)):
    workflow = workflow_manager.get_workflow(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    
    return workflow

@app.post("/workflows/{workflow_id}/execute")
def execute_workflow(workflow_id: int, execution: WorkflowExecute, user_id: int, db: Session = Depends(get_db)):
    result = workflow_manager.execute_workflow(
        workflow_id=workflow_id,
        user_id=user_id,
        user_prompt=execution.user_prompt
    )
    
    return result

@app.get("/executions/{execution_id}")
def get_execution_result(execution_id: int, db: Session = Depends(get_db)):
    result = workflow_manager.get_execution_result(execution_id)
    if not result:
        raise HTTPException(status_code=404, detail="Execution not found")
    
    return result

# AI Tool routes
@app.get("/tools/")
def list_tools(db: Session = Depends(get_db)):
    from ..models.database import AITool
    
    tools = db.query(AITool).filter(AITool.is_active == True).all()
    
    result = []
    for tool in tools:
        result.append({
            "id": tool.id,
            "name": tool.name,
            "description": tool.description,
            "category": tool.category
        })
    
    return {"tools": result}

# Direct tool execution routes (for testing)
@app.post("/tools/chatgpt/execute")
def execute_chatgpt(input_data: Dict[str, Any]):
    try:
        result = chatgpt_integration.execute(input_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/tools/elevenlabs/execute")
def execute_elevenlabs(input_data: Dict[str, Any]):
    try:
        result = elevenlabs_integration.execute(input_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/tools/hashtag-generator/execute")
def execute_hashtag_generator(input_data: Dict[str, Any]):
    try:
        result = hashtag_generator.execute(input_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Main function to run the API
def run_api():
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

if __name__ == "__main__":
    run_api()
