import React, { useState, useEffect } from 'react';
import { useApi } from '../utils/api';

const AIToolIntegrationComponent = ({ toolType }) => {
  const { api, loading, error } = useApi();
  const [inputData, setInputData] = useState({});
  const [result, setResult] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [toolConfig, setToolConfig] = useState({
    title: '',
    description: '',
    inputFields: [],
    executeFunction: null
  });

  useEffect(() => {
    // Configure the component based on the tool type
    switch (toolType) {
      case 'chatgpt':
        setToolConfig({
          title: 'ChatGPT',
          description: 'Generate text content using OpenAI\'s ChatGPT',
          inputFields: [
            { name: 'prompt', label: 'Prompt', type: 'textarea', required: true },
            { name: 'model', label: 'Model', type: 'select', options: ['gpt-4', 'gpt-3.5-turbo'], default: 'gpt-4' },
            { name: 'max_tokens', label: 'Max Tokens', type: 'number', default: 1000 },
            { name: 'temperature', label: 'Temperature', type: 'range', min: 0, max: 1, step: 0.1, default: 0.7 }
          ],
          executeFunction: api.tools.executeChatGPT
        });
        setInputData({ model: 'gpt-4', max_tokens: 1000, temperature: 0.7 });
        break;
      
      case 'elevenlabs':
        setToolConfig({
          title: 'ElevenLabs',
          description: 'Convert text to realistic speech',
          inputFields: [
            { name: 'text', label: 'Text', type: 'textarea', required: true },
            { name: 'voice_id', label: 'Voice', type: 'select', options: [
              { value: '21m00Tcm4TlvDq8ikWAM', label: 'Rachel (Female)' },
              { value: 'AZnzlk1XvdvUeBnXmlld', label: 'Domi (Male)' },
              { value: 'EXAVITQu4vr4xnSDxMaL', label: 'Bella (Female)' },
              { value: 'ErXwobaYiN019PkySvjV', label: 'Antoni (Male)' }
            ], default: '21m00Tcm4TlvDq8ikWAM' },
            { name: 'model_id', label: 'Model', type: 'select', options: [
              { value: 'eleven_monolingual_v1', label: 'Monolingual' },
              { value: 'eleven_multilingual_v1', label: 'Multilingual' }
            ], default: 'eleven_monolingual_v1' }
          ],
          executeFunction: api.tools.executeElevenLabs
        });
        setInputData({ voice_id: '21m00Tcm4TlvDq8ikWAM', model_id: 'eleven_monolingual_v1' });
        break;
      
      case 'hashtag-generator':
        setToolConfig({
          title: 'Hashtag Generator',
          description: 'Generate relevant hashtags for your content',
          inputFields: [
            { name: 'content', label: 'Content', type: 'textarea', required: true },
            { name: 'platform', label: 'Platform', type: 'select', options: [
              'instagram', 'twitter', 'tiktok', 'linkedin'
            ], default: 'instagram' },
            { name: 'count', label: 'Number of Hashtags', type: 'number', min: 5, max: 30, default: 10 }
          ],
          executeFunction: api.tools.executeHashtagGenerator
        });
        setInputData({ platform: 'instagram', count: 10 });
        break;
      
      default:
        setToolConfig({
          title: 'Unknown Tool',
          description: 'Tool type not recognized',
          inputFields: [],
          executeFunction: null
        });
    }
  }, [toolType, api]);

  const handleInputChange = (name, value) => {
    setInputData(prev => ({ ...prev, [name]: value }));
  };

  const executeAITool = async () => {
    // Validate required fields
    const missingFields = toolConfig.inputFields
      .filter(field => field.required && !inputData[field.name])
      .map(field => field.label);
    
    if (missingFields.length > 0) {
      alert(`Please fill in the following required fields: ${missingFields.join(', ')}`);
      return;
    }

    setIsProcessing(true);
    try {
      const result = await toolConfig.executeFunction(inputData);
      setResult(result);
    } catch (err) {
      console.error(`Error executing ${toolConfig.title}:`, err);
    } finally {
      setIsProcessing(false);
    }
  };

  const renderInputField = (field) => {
    switch (field.type) {
      case 'textarea':
        return (
          <textarea
            id={field.name}
            name={field.name}
            rows={4}
            className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
            placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
            value={inputData[field.name] || ''}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
            disabled={isProcessing}
            required={field.required}
          />
        );
      
      case 'select':
        return (
          <select
            id={field.name}
            name={field.name}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            value={inputData[field.name] || field.default}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
            disabled={isProcessing}
          >
            {Array.isArray(field.options) && field.options.map((option, index) => {
              if (typeof option === 'object') {
                return (
                  <option key={index} value={option.value}>
                    {option.label}
                  </option>
                );
              } else {
                return (
                  <option key={index} value={option}>
                    {option}
                  </option>
                );
              }
            })}
          </select>
        );
      
      case 'number':
        return (
          <input
            type="number"
            id={field.name}
            name={field.name}
            className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
            min={field.min}
            max={field.max}
            value={inputData[field.name] || field.default}
            onChange={(e) => handleInputChange(field.name, parseInt(e.target.value))}
            disabled={isProcessing}
          />
        );
      
      case 'range':
        return (
          <div className="flex items-center">
            <input
              type="range"
              id={field.name}
              name={field.name}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              min={field.min}
              max={field.max}
              step={field.step}
              value={inputData[field.name] || field.default}
              onChange={(e) => handleInputChange(field.name, parseFloat(e.target.value))}
              disabled={isProcessing}
            />
            <span className="ml-2 text-sm text-gray-500">
              {inputData[field.name] || field.default}
            </span>
          </div>
        );
      
      default:
        return (
          <input
            type="text"
            id={field.name}
            name={field.name}
            className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
            placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
            value={inputData[field.name] || ''}
            onChange={(e) => handleInputChange(field.name, e.target.value)}
            disabled={isProcessing}
            required={field.required}
          />
        );
    }
  };

  const renderResult = () => {
    if (!result) return null;

    switch (toolType) {
      case 'chatgpt':
        return (
          <div className="mt-4 p-4 bg-gray-50 rounded-md">
            <h4 className="text-sm font-medium text-gray-900">Generated Text:</h4>
            <div className="mt-2 prose prose-sm max-w-none">
              {result.text.split('\n').map((line, i) => (
                <p key={i}>{line}</p>
              ))}
            </div>
            <div className="mt-2 text-xs text-gray-500">
              <p>Model: {result.model}</p>
              <p>Tokens used: {result.usage.total_tokens}</p>
            </div>
          </div>
        );
      
      case 'elevenlabs':
        return (
          <div className="mt-4 p-4 bg-gray-50 rounded-md">
            <h4 className="text-sm font-medium text-gray-900">Generated Audio:</h4>
            <div className="mt-2">
              <audio controls className="w-full">
                <source src={result.audio_url} type="audio/mpeg" />
                Your browser does not support the audio element.
              </audio>
            </div>
            <div className="mt-2 text-xs text-gray-500">
              <p>Voice: {result.voice_id}</p>
              <p>Text length: {result.text_length} characters</p>
            </div>
          </div>
        );
      
      case 'hashtag-generator':
        return (
          <div className="mt-4 p-4 bg-gray-50 rounded-md">
            <h4 className="text-sm font-medium text-gray-900">Generated Hashtags:</h4>
            <div className="mt-2 flex flex-wrap gap-2">
              {result.hashtags.map((hashtag, index) => (
                <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                  {hashtag}
                </span>
              ))}
            </div>
            <div className="mt-2 text-xs text-gray-500">
              <p>Platform: {result.platform}</p>
              <p>Count: {result.count}</p>
            </div>
          </div>
        );
      
      default:
        return (
          <div className="mt-4 p-4 bg-gray-50 rounded-md">
            <h4 className="text-sm font-medium text-gray-900">Result:</h4>
            <pre className="mt-2 text-xs overflow-auto max-h-60">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        );
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">{toolConfig.title}</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">{toolConfig.description}</p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        {toolConfig.inputFields.map((field) => (
          <div key={field.name} className="mb-4">
            <label htmlFor={field.name} className="block text-sm font-medium text-gray-700">
              {field.label} {field.required && <span className="text-red-500">*</span>}
            </label>
            <div className="mt-1">
              {renderInputField(field)}
            </div>
          </div>
        ))}
        
        <div className="flex justify-end">
          <button
            type="button"
            className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
              isProcessing ? 'bg-gray-400' : 'bg-indigo-600 hover:bg-indigo-700'
            } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
            onClick={executeAITool}
            disabled={isProcessing || !toolConfig.executeFunction}
          >
            {isProcessing ? 'Processing...' : `Execute ${toolConfig.title}`}
          </button>
        </div>
        
        {renderResult()}
        
        {error && (
          <div className="mt-4 p-4 rounded-md bg-red-50">
            <p className="text-sm font-medium text-red-800">Error: {error}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIToolIntegrationComponent;
