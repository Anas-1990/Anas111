import os
import logging
import json
from typing import Dict, Any, Optional

import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ChatGPTIntegration:
    """
    Integration with OpenAI's ChatGPT API for text generation.
    """
    
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("OPENAI_API_KEY not found in environment variables")
        else:
            openai.api_key = self.api_key
    
    def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a request to the ChatGPT API.
        
        Args:
            input_data: Dictionary containing:
                - prompt: The user prompt or instruction
                - model: Optional model name (defaults to gpt-4)
                - max_tokens: Optional maximum tokens (defaults to 1000)
                - temperature: Optional temperature (defaults to 0.7)
                
        Returns:
            Dictionary containing the generated text and metadata
        """
        if not self.api_key:
            raise ValueError("OpenAI API key not configured")
        
        prompt = input_data.get("prompt") or input_data.get("user_prompt")
        if not prompt:
            raise ValueError("No prompt provided in input data")
        
        model = input_data.get("model", "gpt-4")
        max_tokens = input_data.get("max_tokens", 1000)
        temperature = input_data.get("temperature", 0.7)
        
        try:
            response = openai.ChatCompletion.create(
                model=model,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant for content creators."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=max_tokens,
                temperature=temperature
            )
            
            return {
                "text": response.choices[0].message.content,
                "model": model,
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens
                }
            }
            
        except Exception as e:
            logger.error(f"Error calling OpenAI API: {str(e)}")
            raise

class ElevenLabsIntegration:
    """
    Integration with ElevenLabs API for text-to-speech generation.
    """
    
    def __init__(self):
        self.api_key = os.getenv("ELEVENLABS_API_KEY")
        self.base_url = "https://api.elevenlabs.io/v1"
        if not self.api_key:
            logger.warning("ELEVENLABS_API_KEY not found in environment variables")
    
    def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a request to the ElevenLabs API.
        
        Args:
            input_data: Dictionary containing:
                - text: The text to convert to speech
                - voice_id: Optional voice ID (defaults to a standard voice)
                - model_id: Optional model ID
                
        Returns:
            Dictionary containing the audio data URL and metadata
        """
        import requests
        
        if not self.api_key:
            raise ValueError("ElevenLabs API key not configured")
        
        text = input_data.get("text")
        if not text:
            raise ValueError("No text provided in input data")
        
        voice_id = input_data.get("voice_id", "21m00Tcm4TlvDq8ikWAM")  # Default voice
        model_id = input_data.get("model_id", "eleven_monolingual_v1")
        
        headers = {
            "xi-api-key": self.api_key,
            "Content-Type": "application/json"
        }
        
        data = {
            "text": text,
            "model_id": model_id,
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.5
            }
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/text-to-speech/{voice_id}",
                headers=headers,
                json=data
            )
            
            if response.status_code != 200:
                raise ValueError(f"ElevenLabs API error: {response.text}")
            
            # In a real implementation, we would save the audio file
            # For this example, we'll just return a placeholder URL
            audio_url = f"/audio/generated_{voice_id}_{hash(text)}.mp3"
            
            return {
                "audio_url": audio_url,
                "voice_id": voice_id,
                "model_id": model_id,
                "text_length": len(text)
            }
            
        except Exception as e:
            logger.error(f"Error calling ElevenLabs API: {str(e)}")
            raise

class BufferIntegration:
    """
    Integration with Buffer API for social media scheduling.
    """
    
    def __init__(self):
        self.api_key = os.getenv("BUFFER_API_KEY")
        self.base_url = "https://api.bufferapp.com/1"
        if not self.api_key:
            logger.warning("BUFFER_API_KEY not found in environment variables")
    
    def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a request to the Buffer API.
        
        Args:
            input_data: Dictionary containing:
                - text: The post text
                - profile_ids: List of Buffer profile IDs to post to
                - media: Optional media URLs to attach
                - scheduled_at: Optional scheduling time
                
        Returns:
            Dictionary containing the scheduled post details
        """
        import requests
        
        if not self.api_key:
            raise ValueError("Buffer API key not configured")
        
        text = input_data.get("text")
        if not text:
            raise ValueError("No text provided in input data")
        
        profile_ids = input_data.get("profile_ids", [])
        if not profile_ids:
            raise ValueError("No profile IDs provided in input data")
        
        media = input_data.get("media", [])
        scheduled_at = input_data.get("scheduled_at")
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        results = []
        
        try:
            for profile_id in profile_ids:
                data = {
                    "text": text,
                    "profile_id": profile_id
                }
                
                if media:
                    data["media"] = json.dumps(media)
                
                if scheduled_at:
                    data["scheduled_at"] = scheduled_at
                
                response = requests.post(
                    f"{self.base_url}/updates/create.json",
                    headers=headers,
                    data=data
                )
                
                if response.status_code != 200:
                    raise ValueError(f"Buffer API error: {response.text}")
                
                results.append({
                    "profile_id": profile_id,
                    "status": "scheduled" if scheduled_at else "sent",
                    "id": response.json().get("updates", {}).get("id")
                })
            
            return {
                "scheduled_posts": results,
                "count": len(results)
            }
            
        except Exception as e:
            logger.error(f"Error calling Buffer API: {str(e)}")
            raise

class HashtagGenerator:
    """
    Generates relevant hashtags for social media content.
    """
    
    def __init__(self):
        self.openai_integration = ChatGPTIntegration()
    
    def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate hashtags based on content.
        
        Args:
            input_data: Dictionary containing:
                - content: The content to generate hashtags for
                - platform: Optional social media platform (instagram, twitter, tiktok)
                - count: Optional number of hashtags to generate
                
        Returns:
            Dictionary containing the generated hashtags
        """
        content = input_data.get("content") or input_data.get("user_prompt")
        if not content:
            raise ValueError("No content provided in input data")
        
        platform = input_data.get("platform", "instagram")
        count = input_data.get("count", 10)
        
        prompt = f"""Generate {count} relevant hashtags for the following {platform} content. 
        Return only the hashtags separated by spaces, without numbering or bullet points:
        
        {content}"""
        
        try:
            result = self.openai_integration.execute({
                "prompt": prompt,
                "max_tokens": 100,
                "temperature": 0.7
            })
            
            # Parse the hashtags from the result
            hashtags = result["text"].strip().split()
            
            # Ensure all hashtags start with #
            hashtags = [tag if tag.startswith("#") else f"#{tag}" for tag in hashtags]
            
            return {
                "hashtags": hashtags,
                "platform": platform,
                "count": len(hashtags)
            }
            
        except Exception as e:
            logger.error(f"Error generating hashtags: {str(e)}")
            raise

class SponsorMatcher:
    """
    Matches content creators with potential sponsors based on content.
    """
    
    def __init__(self, sponsors_csv_path: Optional[str] = None):
        self.sponsors_data = []
        if sponsors_csv_path and os.path.exists(sponsors_csv_path):
            self._load_sponsors(sponsors_csv_path)
    
    def _load_sponsors(self, csv_path: str) -> None:
        """Load sponsors data from CSV file."""
        import csv
        
        try:
            with open(csv_path, 'r') as file:
                reader = csv.DictReader(file)
                self.sponsors_data = list(reader)
                
            logger.info(f"Loaded {len(self.sponsors_data)} sponsors from {csv_path}")
            
        except Exception as e:
            logger.error(f"Error loading sponsors data: {str(e)}")
    
    def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Match content with potential sponsors.
        
        Args:
            input_data: Dictionary containing:
                - content: The content to match sponsors for
                - categories: Optional list of content categories
                - max_matches: Optional maximum number of matches to return
                
        Returns:
            Dictionary containing the matched sponsors
        """
        if not self.sponsors_data:
            return {"matches": [], "count": 0, "message": "No sponsors data available"}
        
        content = input_data.get("content") or input_data.get("user_prompt")
        if not content:
            raise ValueError("No content provided in input data")
        
        categories = input_data.get("categories", [])
        max_matches = input_data.get("max_matches", 5)
        
        # In a real implementation, this would use NLP or other matching algorithms
        # For this example, we'll use a simple keyword matching approach
        matches = []
        
        for sponsor in self.sponsors_data:
            score = 0
            
            # Match by keywords
            keywords = sponsor.get("keywords", "").lower().split(",")
            for keyword in keywords:
                if keyword.strip() in content.lower():
                    score += 1
            
            # Match by categories
            sponsor_categories = sponsor.get("categories", "").lower().split(",")
            for category in categories:
                if category.lower() in sponsor_categories:
                    score += 2
            
            if score > 0:
                matches.append({
                    "sponsor_name": sponsor.get("name"),
                    "sponsor_id": sponsor.get("id"),
                    "match_score": score,
                    "categories": sponsor_categories,
                    "contact_email": sponsor.get("contact_email")
                })
        
        # Sort by match score and limit to max_matches
        matches.sort(key=lambda x: x["match_score"], reverse=True)
        matches = matches[:max_matches]
        
        return {
            "matches": matches,
            "count": len(matches)
        }
