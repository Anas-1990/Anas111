import React, { useState, useEffect } from 'react';
import { useApi } from '../utils/api';

const WorkflowStepEditor = ({ workflowId, onStepAdded, onStepUpdated }) => {
  const { api, loading, error } = useApi();
  const [availableTools, setAvailableTools] = useState([]);
  const [toolsLoading, setToolsLoading] = useState(true);
  const [stepData, setStepData] = useState({
    tool_id: '',
    step_order: 1,
    input_mapping: {},
    output_mapping: {},
    config: {}
  });
  const [configFields, setConfigFields] = useState([]);

  // Fetch available AI tools
  useEffect(() => {
    const fetchTools = async () => {
      try {
        const result = await api.tools.list();
        setAvailableTools(result.tools || []);
      } catch (err) {
        console.error('Error fetching tools:', err);
      } finally {
        setToolsLoading(false);
      }
    };

    fetchTools();
  }, [api]);

  // Update config fields based on selected tool
  useEffect(() => {
    if (stepData.tool_id) {
      const selectedTool = availableTools.find(tool => tool.id === parseInt(stepData.tool_id));
      if (selectedTool) {
        // Set config fields based on tool type
        switch (selectedTool.name) {
          case 'ChatGPT':
            setConfigFields([
              { name: 'model', label: 'Model', type: 'select', options: ['gpt-4', 'gpt-3.5-turbo'] },
              { name: 'temperature', label: 'Temperature', type: 'range', min: 0, max: 1, step: 0.1 },
              { name: 'max_tokens', label: 'Max Tokens', type: 'number', min: 100, max: 4000 }
            ]);
            setStepData(prev => ({
              ...prev,
              config: { model: 'gpt-4', temperature: 0.7, max_tokens: 1000 }
            }));
            break;
          
          case 'ElevenLabs':
            setConfigFields([
              { name: 'voice_id', label: 'Voice', type: 'select', options: [
                { value: '21m00Tcm4TlvDq8ikWAM', label: 'Rachel (Female)' },
                { value: 'AZnzlk1XvdvUeBnXmlld', label: 'Domi (Male)' }
              ]},
              { name: 'model_id', label: 'Model', type: 'select', options: [
                { value: 'eleven_monolingual_v1', label: 'Monolingual' },
                { value: 'eleven_multilingual_v1', label: 'Multilingual' }
              ]}
            ]);
            setStepData(prev => ({
              ...prev,
              config: { voice_id: '21m00Tcm4TlvDq8ikWAM', model_id: 'eleven_monolingual_v1' }
            }));
            break;
          
          case 'HashtagGenerator':
            setConfigFields([
              { name: 'platform', label: 'Platform', type: 'select', options: ['instagram', 'twitter', 'tiktok'] },
              { name: 'count', label: 'Number of Hashtags', type: 'number', min: 5, max: 30 }
            ]);
            setStepData(prev => ({
              ...prev,
              config: { platform: 'instagram', count: 10 }
            }));
            break;
          
          default:
            setConfigFields([]);
            setStepData(prev => ({ ...prev, config: {} }));
        }
      }
    }
  }, [stepData.tool_id, availableTools]);

  const handleInputChange = (field, value) => {
    setStepData(prev => ({ ...prev, [field]: value }));
  };

  const handleConfigChange = (field, value) => {
    setStepData(prev => ({
      ...prev,
      config: { ...prev.config, [field]: value }
    }));
  };

  const handleMappingChange = (type, key, value) => {
    setStepData(prev => ({
      ...prev,
      [type]: { ...prev[type], [key]: value }
    }));
  };

  const addMappingField = (type) => {
    const newKey = `key_${Object.keys(stepData[type]).length + 1}`;
    handleMappingChange(type, newKey, '');
  };

  const removeMappingField = (type, key) => {
    const newMapping = { ...stepData[type] };
    delete newMapping[key];
    setStepData(prev => ({ ...prev, [type]: newMapping }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const result = await api.workflows.addStep(workflowId, stepData);
      if (onStepAdded) {
        onStepAdded(result);
      }
      
      // Reset form
      setStepData({
        tool_id: '',
        step_order: stepData.step_order + 1,
        input_mapping: {},
        output_mapping: {},
        config: {}
      });
    } catch (err) {
      console.error('Error adding workflow step:', err);
    }
  };

  const renderConfigField = (field) => {
    switch (field.type) {
      case 'select':
        return (
          <select
            id={`config_${field.name}`}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            value={stepData.config[field.name] || ''}
            onChange={(e) => handleConfigChange(field.name, e.target.value)}
          >
            <option value="">Select {field.label}</option>
            {field.options.map((option, index) => {
              if (typeof option === 'object') {
                return (
                  <option key={index} value={option.value}>
                    {option.label}
                  </option>
                );
              } else {
                return (
                  <option key={index} value={option}>
                    {option}
                  </option>
                );
              }
            })}
          </select>
        );
      
      case 'range':
        return (
          <div className="flex items-center">
            <input
              type="range"
              id={`config_${field.name}`}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              min={field.min}
              max={field.max}
              step={field.step}
              value={stepData.config[field.name] || field.min}
              onChange={(e) => handleConfigChange(field.name, parseFloat(e.target.value))}
            />
            <span className="ml-2 text-sm text-gray-500">
              {stepData.config[field.name] || field.min}
            </span>
          </div>
        );
      
      case 'number':
        return (
          <input
            type="number"
            id={`config_${field.name}`}
            className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
            min={field.min}
            max={field.max}
            value={stepData.config[field.name] || field.min}
            onChange={(e) => handleConfigChange(field.name, parseInt(e.target.value))}
          />
        );
      
      default:
        return (
          <input
            type="text"
            id={`config_${field.name}`}
            className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
            value={stepData.config[field.name] || ''}
            onChange={(e) => handleConfigChange(field.name, e.target.value)}
          />
        );
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Add Workflow Step</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">
          Configure an AI tool for this workflow step
        </p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            <div className="sm:col-span-3">
              <label htmlFor="tool_id" className="block text-sm font-medium text-gray-700">
                AI Tool
              </label>
              <div className="mt-1">
                <select
                  id="tool_id"
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  value={stepData.tool_id}
                  onChange={(e) => handleInputChange('tool_id', e.target.value)}
                  required
                >
                  <option value="">Select an AI Tool</option>
                  {availableTools.map(tool => (
                    <option key={tool.id} value={tool.id}>
                      {tool.name} - {tool.category}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="step_order" className="block text-sm font-medium text-gray-700">
                Step Order
              </label>
              <div className="mt-1">
                <input
                  type="number"
                  id="step_order"
                  className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  min="1"
                  value={stepData.step_order}
                  onChange={(e) => handleInputChange('step_order', parseInt(e.target.value))}
                  required
                />
              </div>
            </div>

            {/* Tool Configuration */}
            {stepData.tool_id && configFields.length > 0 && (
              <div className="sm:col-span-6">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Tool Configuration</h4>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="grid grid-cols-1 gap-y-4 gap-x-4 sm:grid-cols-2">
                    {configFields.map(field => (
                      <div key={field.name}>
                        <label htmlFor={`config_${field.name}`} className="block text-sm font-medium text-gray-700">
                          {field.label}
                        </label>
                        <div className="mt-1">
                          {renderConfigField(field)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Input Mapping */}
            <div className="sm:col-span-6">
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-sm font-medium text-gray-700">Input Mapping</h4>
                <button
                  type="button"
                  className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  onClick={() => addMappingField('input_mapping')}
                >
                  Add Input
                </button>
              </div>
              <div className="bg-gray-50 p-4 rounded-md">
                {Object.keys(stepData.input_mapping).length === 0 ? (
                  <p className="text-sm text-gray-500">No input mappings defined. Add one to map data from previous steps.</p>
                ) : (
                  <div className="space-y-3">
                    {Object.entries(stepData.input_mapping).map(([key, value]) => (
                      <div key={key} className="flex items-center space-x-2">
                        <input
                          type="text"
                          className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="Target key"
                          value={key}
                          onChange={(e) => {
                            const newMapping = { ...stepData.input_mapping };
                            delete newMapping[key];
                            newMapping[e.target.value] = value;
                            setStepData(prev => ({ ...prev, input_mapping: newMapping }));
                          }}
                        />
                        <span className="text-gray-500">:</span>
                        <input
                          type="text"
                          className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="Source path"
                          value={value}
                          onChange={(e) => handleMappingChange('input_mapping', key, e.target.value)}
                        />
                        <button
                          type="button"
                          className="inline-flex items-center p-1.5 border border-transparent rounded-full text-red-600 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                          onClick={() => removeMappingField('input_mapping', key)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Output Mapping */}
            <div className="sm:col-span-6">
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-sm font-medium text-gray-700">Output Mapping</h4>
                <button
                  type="button"
                  className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  onClick={() => addMappingField('output_mapping')}
                >
                  Add Output
                </button>
              </div>
              <div className="bg-gray-50 p-4 rounded-md">
                {Object.keys(stepData.output_mapping).length === 0 ? (
                  <p className="text-sm text-gray-500">No output mappings defined. Add one to store results for later steps.</p>
                ) : (
                  <div className="space-y-3">
                    {Object.entries(stepData.output_mapping).map(([key, value]) => (
                      <div key={key} className="flex items-center space-x-2">
                        <input
                          type="text"
                          className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="Target variable"
                          value={key}
                          onChange={(e) => {
                            const newMapping = { ...stepData.output_mapping };
                            delete newMapping[key];
                            newMapping[e.target.value] = value;
                            setStepData(prev => ({ ...prev, output_mapping: newMapping }));
                          }}
                        />
                        <span className="text-gray-500">:</span>
                        <input
                          type="text"
                          className="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="Source path"
                          value={value}
                          onChange={(e) => handleMappingChange('output_mapping', key, e.target.value)}
                        />
                        <button
                          type="button"
                          className="inline-flex items-center p-1.5 border border-transparent rounded-full text-red-600 hover:bg-red-50 focus:outline-none 
(Content truncated due to size limit. Use line ranges to read in chunks)