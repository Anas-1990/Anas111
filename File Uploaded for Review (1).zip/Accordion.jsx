"use client";

import React from 'react';
import { FiChevronDown, FiChevronUp } from 'react-icons/fi';

const Accordion = ({
  items,
  allowMultiple = false,
  defaultOpen = [],
  className = '',
  itemClassName = '',
  headerClassName = '',
  contentClassName = '',
}) => {
  const [openItems, setOpenItems] = React.useState(defaultOpen);

  const toggleItem = (index) => {
    if (allowMultiple) {
      setOpenItems((prev) =>
        prev.includes(index)
          ? prev.filter((i) => i !== index)
          : [...prev, index]
      );
    } else {
      setOpenItems((prev) => (prev.includes(index) ? [] : [index]));
    }
  };

  return (
    <div className={`divide-y divide-gray-200 border border-gray-200 rounded-md ${className}`}>
      {items.map((item, index) => (
        <div key={index} className={`${itemClassName}`}>
          <button
            type="button"
            className={`flex justify-between w-full px-4 py-4 text-left text-gray-800 focus:outline-none ${headerClassName}`}
            onClick={() => toggleItem(index)}
            aria-expanded={openItems.includes(index)}
          >
            <span className="font-medium">{item.title}</span>
            <span className="ml-6 flex items-center">
              {openItems.includes(index) ? (
                <FiChevronUp className="h-5 w-5 text-gray-500" />
              ) : (
                <FiChevronDown className="h-5 w-5 text-gray-500" />
              )}
            </span>
          </button>
          {openItems.includes(index) && (
            <div className={`px-4 pb-4 pt-0 ${contentClassName}`}>
              {typeof item.content === 'function' ? item.content() : item.content}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default Accordion;
