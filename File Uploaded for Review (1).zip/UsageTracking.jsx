import React, { useState, useEffect } from 'react';
import { useApi } from '../utils/api';

const UsageTrackingComponent = ({ userId }) => {
  const { api, loading, error } = useApi();
  const [usageData, setUsageData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [dateRange, setDateRange] = useState('month'); // 'week', 'month', 'year'

  useEffect(() => {
    const fetchUsageData = async () => {
      setIsLoading(true);
      try {
        // In a real implementation, this would call your backend API
        // For demo purposes, we'll create mock data
        const mockData = generateMockUsageData(dateRange);
        setUsageData(mockData);
      } catch (err) {
        console.error('Error fetching usage data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUsageData();
  }, [userId, dateRange]);

  const generateMockUsageData = (range) => {
    let dataPoints = [];
    let toolUsage = {};
    let totalCalls = 0;
    let totalCost = 0;
    
    // Generate different number of data points based on range
    const numPoints = range === 'week' ? 7 : range === 'month' ? 30 : 12;
    
    // Generate mock data for each data point
    for (let i = 0; i < numPoints; i++) {
      const date = new Date();
      if (range === 'week' || range === 'month') {
        date.setDate(date.getDate() - (numPoints - i - 1));
      } else {
        date.setMonth(date.getMonth() - (numPoints - i - 1));
      }
      
      // Generate random usage for this data point
      const dailyCalls = Math.floor(Math.random() * 20) + 1;
      totalCalls += dailyCalls;
      
      // Distribute calls among tools
      const tools = ['ChatGPT', 'ElevenLabs', 'Buffer', 'HashtagGenerator'];
      const dailyToolUsage = {};
      
      let remainingCalls = dailyCalls;
      for (let j = 0; j < tools.length - 1; j++) {
        const toolCalls = Math.floor(Math.random() * remainingCalls);
        dailyToolUsage[tools[j]] = toolCalls;
        
        // Update total tool usage
        toolUsage[tools[j]] = (toolUsage[tools[j]] || 0) + toolCalls;
        
        remainingCalls -= toolCalls;
      }
      
      // Assign remaining calls to last tool
      dailyToolUsage[tools[tools.length - 1]] = remainingCalls;
      toolUsage[tools[tools.length - 1]] = (toolUsage[tools[tools.length - 1]] || 0) + remainingCalls;
      
      // Calculate cost (assuming different costs per tool)
      const dailyCost = 
        dailyToolUsage['ChatGPT'] * 0.03 + 
        dailyToolUsage['ElevenLabs'] * 0.05 + 
        dailyToolUsage['Buffer'] * 0.01 + 
        dailyToolUsage['HashtagGenerator'] * 0.02;
      
      totalCost += dailyCost;
      
      dataPoints.push({
        date: date.toISOString().split('T')[0],
        calls: dailyCalls,
        tools: dailyToolUsage,
        cost: dailyCost.toFixed(2)
      });
    }
    
    return {
      dataPoints,
      summary: {
        totalCalls,
        totalCost: totalCost.toFixed(2),
        toolUsage
      }
    };
  };

  const renderUsageChart = () => {
    if (!usageData || !usageData.dataPoints.length) return null;
    
    const maxCalls = Math.max(...usageData.dataPoints.map(d => d.calls));
    
    return (
      <div className="mt-4">
        <div className="flex items-end space-x-2 h-40">
          {usageData.dataPoints.map((point, index) => {
            const height = (point.calls / maxCalls) * 100;
            return (
              <div key={index} className="flex flex-col items-center flex-1">
                <div 
                  className="w-full bg-indigo-600 rounded-t"
                  style={{ height: `${height}%` }}
                  title={`${point.calls} calls on ${point.date}`}
                ></div>
                {(dateRange === 'week' || (dateRange === 'month' && index % 5 === 0) || (dateRange === 'year')) && (
                  <div className="text-xs text-gray-500 mt-1 truncate w-full text-center">
                    {dateRange === 'year' 
                      ? new Date(point.date).toLocaleString('default', { month: 'short' })
                      : new Date(point.date).getDate()}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-2 text-xs text-gray-500 text-center">
          {dateRange === 'week' ? 'Last 7 days' : dateRange === 'month' ? 'Last 30 days' : 'Last 12 months'}
        </div>
      </div>
    );
  };

  const renderToolUsage = () => {
    if (!usageData || !usageData.summary) return null;
    
    const { toolUsage, totalCalls } = usageData.summary;
    const tools = Object.keys(toolUsage);
    
    return (
      <div className="mt-6">
        <h4 className="text-sm font-medium text-gray-700">Tool Usage Breakdown</h4>
        <div className="mt-2 space-y-2">
          {tools.map(tool => {
            const percentage = ((toolUsage[tool] / totalCalls) * 100).toFixed(1);
            return (
              <div key={tool}>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">{tool}</span>
                  <span className="text-xs text-gray-500">{percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                  <div 
                    className={`h-1.5 rounded-full ${
                      tool === 'ChatGPT' ? 'bg-blue-500' :
                      tool === 'ElevenLabs' ? 'bg-purple-500' :
                      tool === 'Buffer' ? 'bg-green-500' :
                      'bg-pink-500'
                    }`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="bg-white shadow overflow-hidden sm:rounded-lg p-6">
        <div className="animate-pulse flex space-x-4">
          <div className="flex-1 space-y-4 py-1">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Usage Analytics</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Track your API usage and costs over time.</p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        {/* Date range selector */}
        <div className="flex justify-end mb-4">
          <div className="inline-flex shadow-sm rounded-md">
            <button
              type="button"
              className={`relative inline-flex items-center px-4 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium ${
                dateRange === 'week' ? 'text-indigo-700 bg-indigo-50' : 'text-gray-700 hover:bg-gray-50'
              }`}
              onClick={() => setDateRange('week')}
            >
              Week
            </button>
            <button
              type="button"
              className={`relative inline-flex items-center px-4 py-2 border-t border-b border-gray-300 bg-white text-sm font-medium ${
                dateRange === 'month' ? 'text-indigo-700 bg-indigo-50' : 'text-gray-700 hover:bg-gray-50'
              }`}
              onClick={() => setDateRange('month')}
            >
              Month
            </button>
            <button
              type="button"
              className={`relative inline-flex items-center px-4 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium ${
                dateRange === 'year' ? 'text-indigo-700 bg-indigo-50' : 'text-gray-700 hover:bg-gray-50'
              }`}
              onClick={() => setDateRange('year')}
            >
              Year
            </button>
          </div>
        </div>
        
        {/* Summary cards */}
        {usageData && (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <dt className="text-sm font-medium text-gray-500 truncate">Total API Calls</dt>
                <dd className="mt-1 text-3xl font-semibold text-gray-900">{usageData.summary.totalCalls}</dd>
              </div>
            </div>
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <dt className="text-sm font-medium text-gray-500 truncate">Total Cost</dt>
                <dd className="mt-1 text-3xl font-semibold text-gray-900">${usageData.summary.totalCost}</dd>
              </div>
            </div>
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <dt className="text-sm font-medium text-gray-500 truncate">Average Daily Calls</dt>
                <dd className="mt-1 text-3xl font-semibold text-gray-900">
                  {Math.round(usageData.summary.totalCalls / usageData.dataPoints.length)}
                </dd>
              </div>
            </div>
          </div>
        )}
        
        {/* Usage chart */}
        {renderUsageChart()}
        
        {/* Tool usage breakdown */}
        {renderToolUsage()}
        
        {error && (
          <div className="mt-4 p-4 rounded-md bg-red-50">
            <p className="text-sm font-medium text-red-800">Error: {error}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UsageTrackingComponent;
