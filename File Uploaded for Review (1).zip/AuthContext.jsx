"use client";

import React from 'react';

const AuthContext = React.createContext({
  currentUser: null,
  login: () => Promise.resolve(),
  signup: () => Promise.resolve(),
  logout: () => Promise.resolve(),
  resetPassword: () => Promise.resolve(),
  signInWithGoogle: () => Promise.resolve(),
});

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  // Mock authentication functions for demo purposes
  const login = async (email, password) => {
    // In a real app, this would call Firebase or another auth provider
    console.log(`Login attempt with ${email}`);
    
    // Simulate successful login
    setCurrentUser({
      uid: '123456',
      email: email,
      displayName: 'Demo User',
      emailVerified: true,
    });
    
    return Promise.resolve();
  };

  const signup = async (email, password, displayName) => {
    // In a real app, this would call Firebase or another auth provider
    console.log(`Signup attempt with ${email}`);
    
    // Simulate successful signup
    setCurrentUser({
      uid: '123456',
      email: email,
      displayName: displayName || 'New User',
      emailVerified: false,
    });
    
    return Promise.resolve();
  };

  const logout = async () => {
    // In a real app, this would call Firebase or another auth provider
    console.log('Logout attempt');
    
    // Simulate successful logout
    setCurrentUser(null);
    
    return Promise.resolve();
  };

  const resetPassword = async (email) => {
    // In a real app, this would call Firebase or another auth provider
    console.log(`Password reset attempt for ${email}`);
    
    return Promise.resolve();
  };

  const signInWithGoogle = async () => {
    // In a real app, this would call Firebase or another auth provider
    console.log('Google sign-in attempt');
    
    // Simulate successful Google sign-in
    setCurrentUser({
      uid: '789012',
      email: 'google-user@example.com',
      displayName: 'Google User',
      emailVerified: true,
      photoURL: 'https://via.placeholder.com/150',
    });
    
    return Promise.resolve();
  };

  // Effect to simulate auth state change listener
  React.useEffect(() => {
    // In a real app, this would set up a Firebase auth state listener
    console.log('Setting up auth state listener');
    
    // Simulate checking if user is already logged in
    const checkAuthState = () => {
      // For demo, we'll assume no user is logged in initially
      setCurrentUser(null);
      setLoading(false);
    };
    
    checkAuthState();
    
    // Cleanup function
    return () => {
      console.log('Cleaning up auth state listener');
    };
  }, []);

  const value = {
    currentUser,
    login,
    signup,
    logout,
    resetPassword,
    signInWithGoogle,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return React.useContext(AuthContext);
}
