import pytest
from unittest.mock import MagicMock, patch
import sys
import os

# Add the src directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.orchestration.engine import OrchestrationEngine
from src.api_integrations.tools import AITool

class TestOrchestrationEngine:
    @pytest.fixture
    def mock_db(self):
        return MagicMock()
    
    @pytest.fixture
    def orchestration_engine(self, mock_db):
        return OrchestrationEngine(db=mock_db)
    
    def test_init(self, orchestration_engine, mock_db):
        assert orchestration_engine.db == mock_db
    
    def test_register_tool(self, orchestration_engine):
        mock_tool = MagicMock(spec=AITool)
        mock_tool.name = "TestTool"
        mock_tool.id = "test_tool"
        
        orchestration_engine.register_tool(mock_tool)
        assert "test_tool" in orchestration_engine.tools
        assert orchestration_engine.tools["test_tool"] == mock_tool
    
    def test_execute_workflow(self, orchestration_engine, mock_db):
        # Setup mock tools
        mock_tool1 = MagicMock(spec=AITool)
        mock_tool1.name = "Tool1"
        mock_tool1.id = "tool1"
        mock_tool1.execute.return_value = {"result": "Tool1 output"}
        
        mock_tool2 = MagicMock(spec=AITool)
        mock_tool2.name = "Tool2"
        mock_tool2.id = "tool2"
        mock_tool2.execute.return_value = {"result": "Tool2 output"}
        
        orchestration_engine.register_tool(mock_tool1)
        orchestration_engine.register_tool(mock_tool2)
        
        # Setup mock workflow
        mock_workflow = {
            "id": "workflow1",
            "name": "Test Workflow",
            "steps": [
                {
                    "id": "step1",
                    "tool_id": "tool1",
                    "config": {"param1": "value1"},
                    "input_mapping": {},
                    "output_mapping": {"tool1_output": "result"}
                },
                {
                    "id": "step2",
                    "tool_id": "tool2",
                    "config": {"param2": "value2"},
                    "input_mapping": {"input": "tool1_output"},
                    "output_mapping": {"final_output": "result"}
                }
            ]
        }
        
        mock_db.get_workflow.return_value = mock_workflow
        
        # Execute workflow
        result = orchestration_engine.execute_workflow("workflow1", {"user_input": "test"})
        
        # Verify tool executions
        mock_tool1.execute.assert_called_once_with({"param1": "value1", "user_input": "test"})
        mock_tool2.execute.assert_called_once_with({"param2": "value2", "input": "Tool1 output"})
        
        # Verify result
        assert result == {"final_output": "Tool2 output", "tool1_output": "Tool1 output"}
    
    def test_execute_workflow_with_error(self, orchestration_engine, mock_db):
        # Setup mock tool that raises an exception
        mock_tool = MagicMock(spec=AITool)
        mock_tool.name = "ErrorTool"
        mock_tool.id = "error_tool"
        mock_tool.execute.side_effect = Exception("Tool execution failed")
        
        orchestration_engine.register_tool(mock_tool)
        
        # Setup mock workflow
        mock_workflow = {
            "id": "error_workflow",
            "name": "Error Workflow",
            "steps": [
                {
                    "id": "step1",
                    "tool_id": "error_tool",
                    "config": {},
                    "input_mapping": {},
                    "output_mapping": {}
                }
            ]
        }
        
        mock_db.get_workflow.return_value = mock_workflow
        
        # Execute workflow and expect exception
        with pytest.raises(Exception) as excinfo:
            orchestration_engine.execute_workflow("error_workflow", {})
        
        assert "Tool execution failed" in str(excinfo.value)
