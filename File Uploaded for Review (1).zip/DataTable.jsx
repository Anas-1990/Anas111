"use client";

import React from 'react';
import { FiChevronDown, FiChevronUp, FiSearch, FiFilter, FiX } from 'react-icons/fi';

const DataTable = ({
  columns,
  data,
  title,
  description,
  searchable = true,
  filterable = true,
  pagination = true,
  itemsPerPageOptions = [10, 25, 50, 100],
  defaultItemsPerPage = 10,
  actions = []
}) => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [sortColumn, setSortColumn] = React.useState(null);
  const [sortDirection, setSortDirection] = React.useState('asc');
  const [currentPage, setCurrentPage] = React.useState(1);
  const [itemsPerPage, setItemsPerPage] = React.useState(defaultItemsPerPage);
  const [filters, setFilters] = React.useState({});
  const [showFilterPanel, setShowFilterPanel] = React.useState(false);

  // Handle sorting
  const handleSort = (columnId) => {
    if (sortColumn === columnId) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(columnId);
      setSortDirection('asc');
    }
  };

  // Filter data based on search term and filters
  const filteredData = React.useMemo(() => {
    let result = [...data];

    // Apply search
    if (searchTerm) {
      const lowercasedSearch = searchTerm.toLowerCase();
      result = result.filter(item => {
        return columns.some(column => {
          const value = item[column.accessor];
          if (value == null) return false;
          return String(value).toLowerCase().includes(lowercasedSearch);
        });
      });
    }

    // Apply filters
    Object.entries(filters).forEach(([key, value]) => {
      if (value) {
        result = result.filter(item => {
          const itemValue = item[key];
          if (Array.isArray(value)) {
            return value.includes(itemValue);
          } else if (typeof value === 'object' && value !== null) {
            if (value.min !== undefined && value.max !== undefined) {
              return itemValue >= value.min && itemValue <= value.max;
            } else if (value.min !== undefined) {
              return itemValue >= value.min;
            } else if (value.max !== undefined) {
              return itemValue <= value.max;
            }
          }
          return itemValue === value;
        });
      }
    });

    // Apply sorting
    if (sortColumn) {
      result.sort((a, b) => {
        const aValue = a[sortColumn];
        const bValue = b[sortColumn];

        if (aValue == null) return sortDirection === 'asc' ? -1 : 1;
        if (bValue == null) return sortDirection === 'asc' ? 1 : -1;

        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return sortDirection === 'asc'
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
        }

        return sortDirection === 'asc'
          ? aValue - bValue
          : bValue - aValue;
      });
    }

    return result;
  }, [data, searchTerm, filters, sortColumn, sortDirection, columns]);

  // Pagination
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const paginatedData = React.useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    return filteredData.slice(start, end);
  }, [filteredData, currentPage, itemsPerPage]);

  // Reset to first page when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filters, itemsPerPage]);

  // Handle filter change
  const handleFilterChange = (accessor, value) => {
    setFilters(prev => ({
      ...prev,
      [accessor]: value
    }));
  };

  // Clear all filters
  const clearFilters = () => {
    setFilters({});
    setSearchTerm('');
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      {/* Header */}
      {(title || description || searchable || filterable || actions.length > 0) && (
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
            <div>
              {title && (
                <h3 className="text-lg leading-6 font-medium text-gray-900">{title}</h3>
              )}
              {description && (
                <p className="mt-1 max-w-2xl text-sm text-gray-500">{description}</p>
              )}
            </div>
            <div className="mt-4 sm:mt-0 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
              {searchable && (
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <FiSearch className="h-5 w-5 text-gray-400" aria-hidden="true" />
                  </div>
                  <input
                    type="text"
                    className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                    placeholder="Search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              )}
              {filterable && (
                <button
                  type="button"
                  className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  onClick={() => setShowFilterPanel(!showFilterPanel)}
                >
                  <FiFilter className="-ml-1 mr-2 h-5 w-5 text-gray-500" aria-hidden="true" />
                  Filters
                  {Object.keys(filters).length > 0 && (
                    <span className="ml-1 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                      {Object.keys(filters).length}
                    </span>
                  )}
                </button>
              )}
              {actions.map((action, index) => (
                <button
                  key={index}
                  type="button"
                  className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium ${
                    action.primary
                      ? 'text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
                      : 'text-gray-700 bg-white border-gray-300 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
                  }`}
                  onClick={action.onClick}
                >
                  {action.icon && (
                    <action.icon className="-ml-1 mr-2 h-5 w-5" aria-hidden="true" />
                  )}
                  {action.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filter Panel */}
          {showFilterPanel && (
            <div className="mt-4 bg-gray-50 p-4 rounded-md">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-sm font-medium text-gray-700">Filters</h4>
                <button
                  type="button"
                  className="text-sm text-indigo-600 hover:text-indigo-900"
                  onClick={clearFilters}
                >
                  Clear all filters
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {columns
                  .filter(column => column.filterable !== false)
                  .map(column => (
                    <div key={column.accessor} className="space-y-1">
                      <label htmlFor={`filter-${column.accessor}`} className="block text-sm font-medium text-gray-700">
                        {column.Header}
                      </label>
                      {column.filterType === 'select' && column.filterOptions && (
                        <select
                          id={`filter-${column.accessor}`}
                          className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                          value={filters[column.accessor] || ''}
                          onChange={(e) => handleFilterChange(column.accessor, e.target.value)}
                        >
                          <option value="">All</option>
                          {column.filterOptions.map((option, index) => (
                            <option key={index} value={option.value || option}>
                              {option.label || option}
                            </option>
                          ))}
                        </select>
                      )}
                      {column.filterType === 'range' && (
                        <div className="flex space-x-2">
                          <input
                            type="number"
                            className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                            placeholder="Min"
                            value={(filters[column.accessor]?.min || '')}
                            onChange={(e) => handleFilterChange(column.accessor, {
                              ...filters[column.accessor],
                              min: e.target.value ? Number(e.target.value) : undefined
                            })}
                          />
                          <input
                            type="number"
                            className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                            placeholder="Max"
                            value={(filters[column.accessor]?.max || '')}
                            onChange={(e) => handleFilterChange(column.accessor, {
                              ...filters[column.accessor],
                              max: e.target.value ? Number(e.target.value) : undefined
                            })}
                          />
                        </div>
                      )}
                      {(!column.filterType || column.filterType === 'text') && (
                        <input
                          type="text"
                          id={`filter-${column.accessor}`}
                          className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                          placeholder={`Filter by ${column.Header}`}
                          value={filters[column.accessor] || ''}
                          onChange={(e) => handleFilterChange(column.accessor, e.target.value)}
                        />
                      )}
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {columns.map(column => (
                <th
                  key={column.accessor}
                  scope="col"
                  className={`px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${
                    column.sortable !== false ? 'cursor-pointer hover:bg-gray-100' : ''
                  }`}
                  onClick={() => column.sortable !== false && handleSort(column.accessor)}
                >
                  <div className="flex items-center">
                    {column.Header}
                    {sortColumn === column.accessor && (
                      <span className="ml-2">
                        {sortDirection === 'asc' ? (
                          <FiChevronUp className="h-4 w-4" />
                        ) : (
                          <FiChevronDown className="h-4 w-4" />
                        )}
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {paginatedData.length > 0 ? (
              paginatedData.map((row, rowIndex) => (
                <tr key={rowIndex} className="hover:bg-gray-50">
                  {columns.map(column => (
                    <td key={column.accessor} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {column.Cell ? column.Cell({ value: row[column.accessor], row }) : row[column.accessor]}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length} className="px-6 py-4 text-center text-sm text-gray-500">
                  No data available
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pagination && filteredData.length > 0 && (
        <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
          <div className="flex-1 flex justify-between sm:hidden">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className={`relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 ${
                currentPage === 1 ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              Previous
            </button>
            <button
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className={`ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 ${
                currentPage === totalPages ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              Next
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Showing <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}</span> to{' '}
                <span className="font-medium">
                  {Math.min(currentPage * itemsPerPage, filteredData.length)}
                </span>{' '}
                of <span className="font-medium">{filteredData.length}</span> results
              </p>
            </div>
            <div className="flex items-center">
              <div className="mr-4">
                <select
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  value={itemsPerPage}
                  onChange={(e) => setItemsPerPage(Number(e.target.value))}
                >
                  {itemsPerPageOptions.map(option => (
                    <option key={option} value={option}>
                      {option} per page
                    </option>
                  ))}
                </select>
              </div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className={`relative inline-flex items-cent
(Content truncated due to size limit. Use line ranges to read in chunks)