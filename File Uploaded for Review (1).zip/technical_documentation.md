# AI Tool Aggregator Platform - Technical Documentation

## Overview

The AI Tool Aggregator Platform is a subscription-based SaaS solution designed for influencers and content creators. It integrates multiple AI tools into a unified platform with workflow automation capabilities, allowing users to streamline their content creation process.

## System Architecture

### Backend Components

The backend is built with a modular architecture consisting of the following components:

1. **Orchestration Engine**: Coordinates the execution of workflows between different AI tools
2. **API Integrations**: Connects to external AI services (ChatGPT, ElevenLabs, etc.)
3. **Workflow Manager**: Handles the creation, execution, and management of workflows
4. **Database Models**: Manages user data, subscription information, and usage tracking
5. **API Layer**: Provides RESTful endpoints for the frontend to interact with

### Frontend Components

The frontend is built with Next.js and includes:

1. **Dashboard**: Shows user's remaining AI credits and workflow status
2. **Workflow Editor**: Interface for creating and editing workflows
3. **Subscription Management**: Handles plan upgrades, downgrades, and billing
4. **Output Review**: Allows users to review and edit AI-generated content

### Database Schema

The platform uses PostgreSQL with the following main tables:

- **Users**: User account information
- **Subscriptions**: Subscription tiers and billing information
- **AITools**: Available AI tools and their configurations
- **Workflows**: User-created workflows
- **WorkflowSteps**: Individual steps within workflows
- **Executions**: Records of workflow executions
- **Usage**: Tracking of API usage and credit consumption

### Caching

Redis is used for:
- Caching frequent API responses
- Rate limiting
- Session management
- Temporary storage of workflow execution results

## Installation and Setup

### Prerequisites

- Node.js 18+
- Python 3.10+
- PostgreSQL 14+
- Redis 6+

### Environment Variables

Create a `.env` file in the root directory with the following variables:

```
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/ai_tool_aggregator

# Redis
REDIS_URL=redis://localhost:6379

# Authentication
JWT_SECRET=your_jwt_secret
ENCRYPTION_KEY=your_32_character_encryption_key

# External APIs
OPENAI_API_KEY=your_openai_api_key
ELEVENLABS_API_KEY=your_elevenlabs_api_key
BUFFER_API_KEY=your_buffer_api_key

# Stripe
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
STRIPE_PRICE_BASIC=price_basic_id
STRIPE_PRICE_PRO=price_pro_id
STRIPE_PRICE_ENTERPRISE=price_enterprise_id

# Firebase (for authentication)
NEXT_PUBLIC_FIREBASE_API_KEY=your_firebase_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_firebase_auth_domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_firebase_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_firebase_storage_bucket
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_firebase_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_firebase_app_id
```

### Backend Setup

1. Navigate to the backend directory:
   ```
   cd ai-tool-aggregator/backend
   ```

2. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Initialize the database:
   ```
   python src/models/init_db.py
   ```

5. Start the backend server:
   ```
   uvicorn src.api.main:app --reload
   ```

### Frontend Setup

1. Navigate to the frontend directory:
   ```
   cd ai-tool-aggregator/frontend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```

## Deployment

### Backend Deployment

The backend can be deployed using Docker:

1. Build the Docker image:
   ```
   docker build -t ai-tool-aggregator-backend ./backend
   ```

2. Run the container:
   ```
   docker run -p 8000:8000 --env-file .env ai-tool-aggregator-backend
   ```

### Frontend Deployment

The frontend can be deployed to Vercel:

1. Install Vercel CLI:
   ```
   npm install -g vercel
   ```

2. Deploy:
   ```
   cd frontend
   vercel
   ```

## API Documentation

### Authentication

All API endpoints (except for authentication endpoints) require a valid JWT token in the Authorization header:

```
Authorization: Bearer <token>
```

### Rate Limiting

API endpoints are rate-limited based on the user's subscription tier:
- Basic: 10 requests per minute
- Pro: 30 requests per minute
- Enterprise: 100 requests per minute

### Endpoints

#### Authentication

- `POST /api/auth/register`: Register a new user
- `POST /api/auth/login`: Login and get JWT token
- `POST /api/auth/refresh`: Refresh JWT token
- `POST /api/auth/2fa/generate`: Generate 2FA secret
- `POST /api/auth/2fa/verify`: Verify 2FA token

#### Users

- `GET /api/users/me`: Get current user information
- `PUT /api/users/me`: Update user information

#### Workflows

- `GET /api/workflows`: List user's workflows
- `POST /api/workflows`: Create a new workflow
- `GET /api/workflows/{id}`: Get workflow details
- `PUT /api/workflows/{id}`: Update workflow
- `DELETE /api/workflows/{id}`: Delete workflow
- `POST /api/workflows/{id}/execute`: Execute workflow

#### AI Tools

- `GET /api/tools`: List available AI tools
- `GET /api/tools/{id}`: Get tool details

#### Subscriptions

- `GET /api/subscriptions`: Get user's subscription
- `POST /api/subscriptions/upgrade`: Upgrade subscription
- `POST /api/subscriptions/cancel`: Cancel subscription
- `GET /api/subscriptions/usage`: Get usage statistics

## Security Features

### Authentication

- Firebase Authentication for user management
- JWT tokens for API authentication
- Two-factor authentication option

### Data Protection

- AES-256-CBC encryption for sensitive data
- HTTPS for all communications
- Secure password hashing

### API Security

- Rate limiting to prevent abuse
- Input validation and sanitization
- CORS configuration
- Security headers (CSP, HSTS, etc.)

## Monitoring and Logging

The platform uses structured logging with the following components:

- Application logs: Detailed application events
- Access logs: HTTP request/response information
- Error logs: Exceptions and error conditions
- Audit logs: Security-relevant events

Logs are stored in the `/var/log/ai-tool-aggregator/` directory and rotated daily.

## Troubleshooting

### Common Issues

1. **Database Connection Errors**:
   - Check PostgreSQL service is running
   - Verify DATABASE_URL environment variable
   - Ensure database user has proper permissions

2. **Redis Connection Errors**:
   - Check Redis service is running
   - Verify REDIS_URL environment variable

3. **API Integration Failures**:
   - Verify API keys are valid
   - Check external service status
   - Review rate limits of external services

4. **Authentication Issues**:
   - Verify Firebase configuration
   - Check JWT_SECRET environment variable
   - Clear browser cookies and try again

### Support

For additional support, contact the development team at support@ai-tool-aggregator.com or open an issue on the GitHub repository.
