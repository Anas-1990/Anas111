"use client";

import React from 'react';
import { FiCreditCard, FiDollarSign, FiUsers, FiBarChart2 } from 'react-icons/fi';

const Card = ({
  title,
  value,
  description,
  icon,
  trend,
  trendValue,
  trendLabel,
  variant = 'default',
  className = '',
  onClick,
  footer,
  loading = false
}) => {
  // Card variants
  const variants = {
    default: 'bg-white',
    primary: 'bg-indigo-50',
    success: 'bg-green-50',
    warning: 'bg-yellow-50',
    danger: 'bg-red-50',
    info: 'bg-blue-50'
  };

  // Trend direction styles
  const trendStyles = {
    up: 'text-green-600 bg-green-100',
    down: 'text-red-600 bg-red-100',
    neutral: 'text-gray-600 bg-gray-100'
  };

  // Icon background styles
  const iconBgStyles = {
    default: 'bg-gray-100 text-gray-600',
    primary: 'bg-indigo-100 text-indigo-600',
    success: 'bg-green-100 text-green-600',
    warning: 'bg-yellow-100 text-yellow-600',
    danger: 'bg-red-100 text-red-600',
    info: 'bg-blue-100 text-blue-600'
  };

  return (
    <div 
      className={`rounded-lg shadow-sm overflow-hidden ${variants[variant]} ${className} ${onClick ? 'cursor-pointer transition-transform hover:scale-[1.02]' : ''}`}
      onClick={onClick}
    >
      <div className="p-5">
        <div className="flex items-center">
          {icon && (
            <div className={`flex-shrink-0 rounded-md p-3 ${iconBgStyles[variant]}`}>
              {React.isValidElement(icon) ? (
                icon
              ) : (
                <icon.icon className="h-6 w-6" aria-hidden="true" />
              )}
            </div>
          )}
          <div className={`${icon ? 'ml-5' : ''} w-full`}>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-500">{title}</h3>
              {trend && (
                <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${trendStyles[trend]}`}>
                  {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '•'} {trendValue}
                  {trendLabel && <span className="ml-1 text-xs opacity-75">{trendLabel}</span>}
                </div>
              )}
            </div>
            
            {loading ? (
              <div className="animate-pulse mt-2 h-8 bg-gray-200 rounded w-1/2"></div>
            ) : (
              <div className="mt-1 flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900">{value}</p>
                {description && (
                  <p className="ml-2 text-sm text-gray-500">{description}</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {footer && (
        <div className="bg-gray-50 px-5 py-3">
          {footer}
        </div>
      )}
    </div>
  );
};

// Predefined card variants
export const StatsCard = ({ title, value, change, period = 'vs. last period', icon = FiBarChart2, ...props }) => (
  <Card
    title={title}
    value={value}
    trend={change > 0 ? 'up' : change < 0 ? 'down' : 'neutral'}
    trendValue={`${Math.abs(change)}%`}
    trendLabel={period}
    icon={{ icon }}
    {...props}
  />
);

export const RevenueCard = ({ value, change, period = 'vs. last month', ...props }) => (
  <StatsCard
    title="Revenue"
    value={value}
    change={change}
    period={period}
    icon={FiDollarSign}
    variant="success"
    {...props}
  />
);

export const UsersCard = ({ value, change, period = 'vs. last month', ...props }) => (
  <StatsCard
    title="Active Users"
    value={value}
    change={change}
    period={period}
    icon={FiUsers}
    variant="primary"
    {...props}
  />
);

export const SubscriptionsCard = ({ value, change, period = 'vs. last month', ...props }) => (
  <StatsCard
    title="Subscriptions"
    value={value}
    change={change}
    period={period}
    icon={FiCreditCard}
    variant="info"
    {...props}
  />
);

export default Card;
