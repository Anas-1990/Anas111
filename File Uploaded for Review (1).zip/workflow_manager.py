import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

from sqlalchemy.orm import Session

from ..models.database import (
    User, AITool, Workflow, WorkflowStep, 
    WorkflowExecution, StepExecution
)
from ..orchestration.engine import OrchestrationEngine

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WorkflowManager:
    """
    Manages workflow creation, editing, and template management.
    """
    
    def __init__(self, db_session: Session, orchestration_engine: OrchestrationEngine):
        self.db_session = db_session
        self.orchestration_engine = orchestration_engine
    
    def create_workflow(self, user_id: int, name: str, description: str, 
                       is_template: bool = False, template_category: Optional[str] = None) -> int:
        """
        Create a new workflow.
        
        Args:
            user_id: ID of the user creating the workflow
            name: Name of the workflow
            description: Description of the workflow
            is_template: Whether this workflow is a template
            template_category: Category for template workflows
            
        Returns:
            ID of the created workflow
        """
        workflow = Workflow(
            user_id=user_id,
            name=name,
            description=description,
            is_template=is_template,
            template_category=template_category
        )
        self.db_session.add(workflow)
        self.db_session.commit()
        
        logger.info(f"Created workflow {workflow.id} for user {user_id}")
        return workflow.id
    
    def add_workflow_step(self, workflow_id: int, tool_id: int, step_order: int,
                         input_mapping: Optional[Dict[str, str]] = None,
                         output_mapping: Optional[Dict[str, str]] = None,
                         config: Optional[Dict[str, Any]] = None) -> int:
        """
        Add a step to a workflow.
        
        Args:
            workflow_id: ID of the workflow
            tool_id: ID of the AI tool to use for this step
            step_order: Order of this step in the workflow
            input_mapping: Mapping of inputs from previous steps
            output_mapping: Mapping of outputs to variables
            config: Step-specific configuration
            
        Returns:
            ID of the created workflow step
        """
        step = WorkflowStep(
            workflow_id=workflow_id,
            tool_id=tool_id,
            step_order=step_order,
            input_mapping=json.dumps(input_mapping) if input_mapping else None,
            output_mapping=json.dumps(output_mapping) if output_mapping else None,
            config=json.dumps(config) if config else None
        )
        self.db_session.add(step)
        self.db_session.commit()
        
        logger.info(f"Added step {step.id} to workflow {workflow_id}")
        return step.id
    
    def update_workflow(self, workflow_id: int, name: Optional[str] = None, 
                       description: Optional[str] = None) -> bool:
        """
        Update a workflow's details.
        
        Args:
            workflow_id: ID of the workflow to update
            name: New name for the workflow
            description: New description for the workflow
            
        Returns:
            True if successful, False otherwise
        """
        workflow = self.db_session.query(Workflow).filter(Workflow.id == workflow_id).first()
        if not workflow:
            logger.error(f"Workflow with ID {workflow_id} not found")
            return False
        
        if name:
            workflow.name = name
        if description:
            workflow.description = description
            
        workflow.updated_at = datetime.utcnow()
        self.db_session.commit()
        
        logger.info(f"Updated workflow {workflow_id}")
        return True
    
    def delete_workflow(self, workflow_id: int) -> bool:
        """
        Delete a workflow.
        
        Args:
            workflow_id: ID of the workflow to delete
            
        Returns:
            True if successful, False otherwise
        """
        workflow = self.db_session.query(Workflow).filter(Workflow.id == workflow_id).first()
        if not workflow:
            logger.error(f"Workflow with ID {workflow_id} not found")
            return False
        
        # Delete associated steps
        self.db_session.query(WorkflowStep).filter(WorkflowStep.workflow_id == workflow_id).delete()
        
        # Delete the workflow
        self.db_session.delete(workflow)
        self.db_session.commit()
        
        logger.info(f"Deleted workflow {workflow_id}")
        return True
    
    def get_workflow(self, workflow_id: int) -> Optional[Dict[str, Any]]:
        """
        Get details of a workflow.
        
        Args:
            workflow_id: ID of the workflow
            
        Returns:
            Dict containing workflow details, or None if not found
        """
        workflow = self.db_session.query(Workflow).filter(Workflow.id == workflow_id).first()
        if not workflow:
            logger.error(f"Workflow with ID {workflow_id} not found")
            return None
        
        steps = self.db_session.query(WorkflowStep).filter(
            WorkflowStep.workflow_id == workflow_id
        ).order_by(WorkflowStep.step_order).all()
        
        step_details = []
        for step in steps:
            tool = self.db_session.query(AITool).filter(AITool.id == step.tool_id).first()
            step_details.append({
                "id": step.id,
                "order": step.step_order,
                "tool": {
                    "id": tool.id,
                    "name": tool.name,
                    "category": tool.category
                },
                "input_mapping": json.loads(step.input_mapping) if step.input_mapping else {},
                "output_mapping": json.loads(step.output_mapping) if step.output_mapping else {},
                "config": json.loads(step.config) if step.config else {}
            })
        
        return {
            "id": workflow.id,
            "name": workflow.name,
            "description": workflow.description,
            "is_template": workflow.is_template,
            "template_category": workflow.template_category,
            "created_at": workflow.created_at.isoformat(),
            "updated_at": workflow.updated_at.isoformat(),
            "steps": step_details
        }
    
    def list_workflows(self, user_id: Optional[int] = None, 
                      is_template: Optional[bool] = None,
                      template_category: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List workflows, optionally filtered by user, template status, or category.
        
        Args:
            user_id: Filter by user ID
            is_template: Filter by template status
            template_category: Filter by template category
            
        Returns:
            List of workflow details
        """
        query = self.db_session.query(Workflow)
        
        if user_id is not None:
            query = query.filter(Workflow.user_id == user_id)
        if is_template is not None:
            query = query.filter(Workflow.is_template == is_template)
        if template_category:
            query = query.filter(Workflow.template_category == template_category)
            
        workflows = query.all()
        
        result = []
        for workflow in workflows:
            result.append({
                "id": workflow.id,
                "name": workflow.name,
                "description": workflow.description,
                "is_template": workflow.is_template,
                "template_category": workflow.template_category,
                "created_at": workflow.created_at.isoformat(),
                "updated_at": workflow.updated_at.isoformat()
            })
            
        return result
    
    def clone_workflow(self, source_workflow_id: int, user_id: int, 
                      new_name: Optional[str] = None) -> Optional[int]:
        """
        Clone a workflow for a user.
        
        Args:
            source_workflow_id: ID of the workflow to clone
            user_id: ID of the user who will own the cloned workflow
            new_name: Name for the cloned workflow
            
        Returns:
            ID of the cloned workflow, or None if source not found
        """
        source = self.db_session.query(Workflow).filter(Workflow.id == source_workflow_id).first()
        if not source:
            logger.error(f"Source workflow with ID {source_workflow_id} not found")
            return None
        
        # Create new workflow
        name = new_name if new_name else f"Copy of {source.name}"
        new_workflow = Workflow(
            user_id=user_id,
            name=name,
            description=source.description,
            is_template=False  # Cloned workflows are not templates by default
        )
        self.db_session.add(new_workflow)
        self.db_session.commit()
        
        # Clone steps
        source_steps = self.db_session.query(WorkflowStep).filter(
            WorkflowStep.workflow_id == source_workflow_id
        ).order_by(WorkflowStep.step_order).all()
        
        for step in source_steps:
            new_step = WorkflowStep(
                workflow_id=new_workflow.id,
                tool_id=step.tool_id,
                step_order=step.step_order,
                input_mapping=step.input_mapping,
                output_mapping=step.output_mapping,
                config=step.config
            )
            self.db_session.add(new_step)
            
        self.db_session.commit()
        
        logger.info(f"Cloned workflow {source_workflow_id} to {new_workflow.id} for user {user_id}")
        return new_workflow.id
    
    def execute_workflow(self, workflow_id: int, user_id: int, user_prompt: str) -> Dict[str, Any]:
        """
        Execute a workflow.
        
        Args:
            workflow_id: ID of the workflow to execute
            user_id: ID of the user executing the workflow
            user_prompt: User's input prompt for the workflow
            
        Returns:
            Dict containing execution results and status
        """
        return self.orchestration_engine.execute_workflow(workflow_id, user_id, user_prompt)
    
    def get_execution_result(self, execution_id: int) -> Optional[Dict[str, Any]]:
        """
        Get the results of a workflow execution.
        
        Args:
            execution_id: ID of the workflow execution
            
        Returns:
            Dict containing execution results, or None if not found
        """
        execution = self.db_session.query(WorkflowExecution).filter(
            WorkflowExecution.id == execution_id
        ).first()
        
        if not execution:
            logger.error(f"Execution with ID {execution_id} not found")
            return None
        
        step_executions = self.db_session.query(StepExecution).filter(
            StepExecution.workflow_execution_id == execution_id
        ).all()
        
        step_results = []
        for step_exec in step_executions:
            step_results.append({
                "step_id": step_exec.step_id,
                "status": step_exec.status,
                "started_at": step_exec.started_at.isoformat() if step_exec.started_at else None,
                "completed_at": step_exec.completed_at.isoformat() if step_exec.completed_at else None,
                "input_data": json.loads(step_exec.input_data) if step_exec.input_data else {},
                "output_data": json.loads(step_exec.output_data) if step_exec.output_data else {},
                "error": step_exec.error
            })
        
        return {
            "id": execution.id,
            "workflow_id": execution.workflow_id,
            "user_prompt": execution.user_prompt,
            "status": execution.status,
            "started_at": execution.started_at.isoformat() if execution.started_at else None,
            "completed_at": execution.completed_at.isoformat() if execution.completed_at else None,
            "result": json.loads(execution.result) if execution.result else {},
            "steps": step_results
        }
