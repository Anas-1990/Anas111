import { NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';

// Rate limiting configuration
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute in milliseconds
const RATE_LIMIT_MAX_REQUESTS = {
  'Basic': 10,  // 10 requests per minute
  'Pro': 30,    // 30 requests per minute
  'Enterprise': 100 // 100 requests per minute
};

// IP-based rate limiting storage
// In production, this should use Redis or another distributed cache
const ipRequestCounts = new Map();

export async function middleware(request) {
  // Get the pathname
  const path = request.nextUrl.pathname;
  
  // Skip middleware for non-API routes and public assets
  if (!path.startsWith('/api/') || 
      path.startsWith('/api/auth') || 
      path.includes('.') || 
      path.includes('favicon.ico')) {
    return NextResponse.next();
  }

  // Get the JWT token
  const token = await getToken({ req: request });
  
  // Check authentication for API routes
  if (!token && path.startsWith('/api/')) {
    return new NextResponse(
      JSON.stringify({ error: 'Authentication required' }),
      { status: 401, headers: { 'Content-Type': 'application/json' } }
    );
  }

  // Apply rate limiting
  const clientIp = request.headers.get('x-forwarded-for') || 'unknown';
  const userTier = token?.subscription?.tier || 'Basic';
  const rateLimit = RATE_LIMIT_MAX_REQUESTS[userTier] || RATE_LIMIT_MAX_REQUESTS.Basic;
  
  // Create a unique key for this user/IP combination
  const rateLimitKey = `${token?.sub || clientIp}:${Math.floor(Date.now() / RATE_LIMIT_WINDOW)}`;
  
  // Get current request count
  const currentCount = ipRequestCounts.get(rateLimitKey) || 0;
  
  // Check if rate limit exceeded
  if (currentCount >= rateLimit) {
    return new NextResponse(
      JSON.stringify({ 
        error: 'Rate limit exceeded', 
        limit: rateLimit,
        windowMs: RATE_LIMIT_WINDOW,
        tierUpgrade: userTier !== 'Enterprise' ? 'Consider upgrading your subscription tier for higher rate limits' : null
      }),
      { status: 429, headers: { 'Content-Type': 'application/json' } }
    );
  }
  
  // Increment request count
  ipRequestCounts.set(rateLimitKey, currentCount + 1);
  
  // Clean up old entries every 5 minutes
  if (Math.random() < 0.01) { // 1% chance to run cleanup on each request
    const now = Date.now();
    for (const [key, _] of ipRequestCounts.entries()) {
      const keyTime = parseInt(key.split(':')[1]) * RATE_LIMIT_WINDOW;
      if (now - keyTime > RATE_LIMIT_WINDOW) {
        ipRequestCounts.delete(key);
      }
    }
  }
  
  // Add security headers
  const response = NextResponse.next();
  
  // Set security headers
  const securityHeaders = {
    'X-DNS-Prefetch-Control': 'on',
    'Strict-Transport-Security': 'max-age=63072000; includeSubDomains; preload',
    'X-XSS-Protection': '1; mode=block',
    'X-Frame-Options': 'SAMEORIGIN',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'origin-when-cross-origin',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://js.stripe.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' https://api.stripe.com;"
  };
  
  // Apply security headers
  Object.entries(securityHeaders).forEach(([key, value]) => {
    response.headers.set(key, value);
  });
  
  return response;
}

// Configure which paths this middleware is applied to
export const config = {
  matcher: [
    // Apply to all API routes
    '/api/:path*',
    // Exclude Next.js internals
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
};
