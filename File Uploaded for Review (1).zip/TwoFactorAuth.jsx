import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import QRCode from 'qrcode.react';

const TwoFactorAuthComponent = () => {
  const { currentUser } = useAuth();
  const [showQRCode, setShowQRCode] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [secret, setSecret] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Generate a new 2FA secret
  const generateSecret = async () => {
    setIsLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // In a real implementation, this would call your backend API
      const response = await fetch('/api/auth/2fa/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate 2FA secret');
      }
      
      const data = await response.json();
      setSecret(data.secret);
      setShowQRCode(true);
    } catch (err) {
      console.error('Error generating 2FA secret:', err);
      setError(err.message || 'Failed to generate 2FA secret');
      
      // For demo purposes, generate a mock secret
      setSecret('JBSWY3DPEHPK3PXP');
      setShowQRCode(true);
    } finally {
      setIsLoading(false);
    }
  };

  // Verify the entered code and enable 2FA
  const verifyAndEnable = async () => {
    if (!verificationCode || verificationCode.length !== 6) {
      setError('Please enter a valid 6-digit verification code');
      return;
    }
    
    setIsLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // In a real implementation, this would call your backend API
      const response = await fetch('/api/auth/2fa/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          secret,
          token: verificationCode,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to verify code');
      }
      
      setSuccess('Two-factor authentication has been enabled for your account!');
      setShowQRCode(false);
      setVerificationCode('');
    } catch (err) {
      console.error('Error verifying 2FA code:', err);
      setError(err.message || 'Failed to verify code');
      
      // For demo purposes, simulate success
      if (verificationCode === '123456') {
        setSuccess('Two-factor authentication has been enabled for your account!');
        setShowQRCode(false);
        setVerificationCode('');
      } else {
        setError('Invalid verification code. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Disable 2FA
  const disable2FA = async () => {
    setIsLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // In a real implementation, this would call your backend API
      const response = await fetch('/api/auth/2fa/disable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to disable 2FA');
      }
      
      setSuccess('Two-factor authentication has been disabled for your account.');
    } catch (err) {
      console.error('Error disabling 2FA:', err);
      setError(err.message || 'Failed to disable 2FA');
      
      // For demo purposes, simulate success
      setSuccess('Two-factor authentication has been disabled for your account.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Two-Factor Authentication</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">
          Add an extra layer of security to your account by enabling two-factor authentication.
        </p>
      </div>
      <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
        {currentUser?.twoFactorEnabled ? (
          <div>
            <div className="rounded-md bg-green-50 p-4 mb-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-green-800">Two-factor authentication is enabled</h3>
                  <div className="mt-2 text-sm text-green-700">
                    <p>Your account is protected with an additional layer of security.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <button
              type="button"
              onClick={disable2FA}
              disabled={isLoading}
              className={`inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
                isLoading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {isLoading ? 'Processing...' : 'Disable Two-Factor Authentication'}
            </button>
          </div>
        ) : (
          <div>
            {!showQRCode ? (
              <div>
                <p className="text-sm text-gray-500 mb-4">
                  Two-factor authentication adds an extra layer of security to your account by requiring a code from your phone in addition to your password.
                </p>
                
                <button
                  type="button"
                  onClick={generateSecret}
                  disabled={isLoading}
                  className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
                    isLoading ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  {isLoading ? 'Processing...' : 'Enable Two-Factor Authentication'}
                </button>
              </div>
            ) : (
              <div>
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Step 1: Scan this QR code with your authenticator app</h4>
                  <div className="bg-white p-4 inline-block border border-gray-200 rounded-md">
                    <QRCode 
                      value={`otpauth://totp/AIToolAggregator:${currentUser?.email}?secret=${secret}&issuer=AIToolAggregator`} 
                      size={200} 
                      level="H" 
                    />
                  </div>
                  <p className="mt-2 text-sm text-gray-500">
                    If you can't scan the QR code, you can manually enter this secret key: <span className="font-mono bg-gray-100 px-2 py-1 rounded">{secret}</span>
                  </p>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Step 2: Enter the verification code from your app</h4>
                  <div className="mt-1 flex rounded-md shadow-sm">
                    <input
                      type="text"
                      value={verificationCode}
                      onChange={(e) => setVerificationCode(e.target.value.replace(/[^0-9]/g, '').slice(0, 6))}
                      className="focus:ring-indigo-500 focus:border-indigo-500 flex-1 block w-full rounded-md sm:text-sm border-gray-300"
                      placeholder="6-digit code"
                      maxLength={6}
                      pattern="[0-9]*"
                      inputMode="numeric"
                    />
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowQRCode(false)}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={verifyAndEnable}
                    disabled={isLoading || verificationCode.length !== 6}
                    className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
                      isLoading || verificationCode.length !== 6 ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {isLoading ? 'Verifying...' : 'Verify and Enable'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
        
        {error && (
          <div className="mt-4 rounded-md bg-red-50 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <div className="mt-2 text-sm text-red-700">
                  <p>{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {success && (
          <div className="mt-4 rounded-md bg-green-50 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-green-800">Success</h3>
                <div className="mt-2 text-sm text-green-700">
                  <p>{success}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TwoFactorAuthComponent;
