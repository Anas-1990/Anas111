import pytest
import requests
import json
import os
import sys
from unittest.mock import patch

# Add the src directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Import the FastAPI app
from src.api.main import app
from fastapi.testclient import TestClient

# Create a test client
client = TestClient(app)

class TestAPIIntegration:
    @pytest.fixture
    def mock_auth_middleware(self):
        # Patch the authentication middleware to always return a valid user
        with patch('src.api.main.get_current_user') as mock:
            mock.return_value = {
                "id": "test_user_id",
                "email": "test@example.com",
                "subscription_tier": "Pro"
            }
            yield mock
    
    @pytest.fixture
    def mock_orchestration_engine(self):
        with patch('src.api.main.orchestration_engine') as mock:
            mock.execute_workflow.return_value = {
                "result": "Workflow executed successfully",
                "steps": [
                    {"tool": "ChatGPT", "output": "Generated content"},
                    {"tool": "ElevenLabs", "output": "Generated audio"}
                ]
            }
            yield mock
    
    def test_health_check(self):
        response = client.get("/api/health")
        assert response.status_code == 200
        assert response.json() == {"status": "healthy"}
    
    def test_get_tools(self, mock_auth_middleware):
        response = client.get("/api/tools")
        assert response.status_code == 200
        tools = response.json()["tools"]
        assert isinstance(tools, list)
        assert len(tools) > 0
        
        # Check tool structure
        for tool in tools:
            assert "id" in tool
            assert "name" in tool
            assert "description" in tool
            assert "category" in tool
    
    def test_execute_workflow(self, mock_auth_middleware, mock_orchestration_engine):
        workflow_id = "test_workflow_id"
        request_data = {
            "user_prompt": "Create a TikTok video about AI tools"
        }
        
        response = client.post(f"/api/workflows/{workflow_id}/execute", json=request_data)
        assert response.status_code == 200
        result = response.json()
        
        assert "execution_id" in result
        assert "status" in result
        
        # Verify orchestration engine was called
        mock_orchestration_engine.execute_workflow.assert_called_once_with(
            workflow_id, 
            {"user_prompt": "Create a TikTok video about AI tools", "user_id": "test_user_id"}
        )
    
    def test_get_execution_result(self, mock_auth_middleware):
        execution_id = "test_execution_id"
        
        # Mock the database response
        with patch('src.api.main.db.get_execution') as mock_get_execution:
            mock_get_execution.return_value = {
                "id": execution_id,
                "workflow_id": "test_workflow_id",
                "user_id": "test_user_id",
                "status": "Completed",
                "result": {
                    "final_output": "This is the final output",
                    "steps": [
                        {"tool": "ChatGPT", "output": "Generated content"},
                        {"tool": "ElevenLabs", "output": "Generated audio"}
                    ]
                },
                "created_at": "2025-04-09T12:00:00Z",
                "updated_at": "2025-04-09T12:05:00Z"
            }
            
            response = client.get(f"/api/executions/{execution_id}")
            assert response.status_code == 200
            result = response.json()
            
            assert result["id"] == execution_id
            assert result["status"] == "Completed"
            assert "result" in result
            assert "final_output" in result["result"]
    
    def test_create_workflow(self, mock_auth_middleware):
        workflow_data = {
            "name": "Test Workflow",
            "description": "A test workflow",
            "is_template": False
        }
        
        # Mock the database response
        with patch('src.api.main.db.create_workflow') as mock_create_workflow:
            mock_create_workflow.return_value = {
                "id": "new_workflow_id",
                **workflow_data,
                "user_id": "test_user_id",
                "created_at": "2025-04-09T12:00:00Z",
                "updated_at": "2025-04-09T12:00:00Z"
            }
            
            response = client.post("/api/workflows", json=workflow_data)
            assert response.status_code == 201
            result = response.json()
            
            assert result["name"] == workflow_data["name"]
            assert result["description"] == workflow_data["description"]
            assert result["user_id"] == "test_user_id"
    
    def test_unauthorized_access(self):
        # Test without the auth middleware mock to simulate unauthorized access
        response = client.get("/api/workflows")
        assert response.status_code == 401
    
    def test_rate_limiting(self):
        # This would require more complex setup to test properly
        # For now, we'll just check that the rate limiting middleware is applied
        with patch('src.api.main.rate_limit_middleware') as mock_rate_limit:
            mock_rate_limit.return_value = {"status": "rate limit check passed"}
            
            # The actual implementation would check request counts and limits
            pass
