import React from 'react';
import { FiCreditCard, FiUsers, FiActivity, FiBarChart2 } from 'react-icons/fi';

const Dashboard = () => {
  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        
        {/* Stats Cards */}
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-indigo-500 rounded-md p-3">
                  <FiCreditCard className="h-6 w-6 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">AI Credits Remaining</dt>
                    <dd className="flex items-baseline">
                      <div className="text-2xl font-semibold text-gray-900">842</div>
                      <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                        <span>of 1000</span>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-purple-500 rounded-md p-3">
                  <FiActivity className="h-6 w-6 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Active Workflows</dt>
                    <dd className="flex items-baseline">
                      <div className="text-2xl font-semibold text-gray-900">4</div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-pink-500 rounded-md p-3">
                  <FiBarChart2 className="h-6 w-6 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Content Generated</dt>
                    <dd className="flex items-baseline">
                      <div className="text-2xl font-semibold text-gray-900">28</div>
                      <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                        <span>this month</span>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-blue-500 rounded-md p-3">
                  <FiUsers className="h-6 w-6 text-white" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Subscription</dt>
                    <dd className="flex items-baseline">
                      <div className="text-2xl font-semibold text-gray-900">Pro</div>
                      <div className="ml-2 flex items-baseline text-sm font-semibold text-gray-600">
                        <span>Renews in 18 days</span>
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Workflows */}
        <h2 className="mt-8 text-lg font-medium text-gray-900">Recent Workflows</h2>
        <div className="mt-4 bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {[
              { id: 1, name: 'TikTok Viral Video', status: 'Completed', date: '2 hours ago', type: 'Video' },
              { id: 2, name: 'Weekly Blog Post', status: 'In Progress', date: '5 hours ago', type: 'Blog' },
              { id: 3, name: 'Instagram Carousel', status: 'Completed', date: '1 day ago', type: 'Image' },
              { id: 4, name: 'YouTube Script', status: 'Completed', date: '2 days ago', type: 'Text' },
              { id: 5, name: 'Podcast Clip Generator', status: 'Failed', date: '3 days ago', type: 'Audio' },
            ].map((workflow) => (
              <li key={workflow.id}>
                <a href="#" className="block hover:bg-gray-50">
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-indigo-600 truncate">{workflow.name}</p>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                          ${workflow.status === 'Completed' ? 'bg-green-100 text-green-800' : 
                            workflow.status === 'In Progress' ? 'bg-yellow-100 text-yellow-800' : 
                            'bg-red-100 text-red-800'}`}>
                          {workflow.status}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="sm:flex">
                        <p className="flex items-center text-sm text-gray-500">
                          {workflow.type}
                        </p>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                        <p>
                          Last run {workflow.date}
                        </p>
                      </div>
                    </div>
                  </div>
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Recommended Templates */}
        <h2 className="mt-8 text-lg font-medium text-gray-900">Recommended Templates</h2>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { id: 1, name: 'TikTok Viral Video', description: 'Create engaging short-form videos optimized for TikTok algorithm', color: 'bg-pink-500' },
            { id: 2, name: 'Blog-to-Thread', description: 'Convert your blog posts into engaging Twitter threads', color: 'bg-blue-500' },
            { id: 3, name: 'Podcast Clip Generator', description: 'Extract and enhance the best moments from your podcast episodes', color: 'bg-purple-500' },
          ].map((template) => (
            <div key={template.id} className="bg-white overflow-hidden shadow rounded-lg">
              <div className={`${template.color} h-2`}></div>
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium text-gray-900">{template.name}</h3>
                <p className="mt-1 text-sm text-gray-500">{template.description}</p>
                <div className="mt-4">
                  <button
                    type="button"
                    className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Use Template
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
