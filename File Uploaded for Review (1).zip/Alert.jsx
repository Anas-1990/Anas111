"use client";

import React from 'react';
import { FiAlertCircle, FiCheckCircle, FiInfo, FiX } from 'react-icons/fi';

const variants = {
  info: {
    containerClass: 'bg-blue-50',
    iconClass: 'text-blue-400',
    titleClass: 'text-blue-800',
    textClass: 'text-blue-700',
    Icon: FiInfo
  },
  success: {
    containerClass: 'bg-green-50',
    iconClass: 'text-green-400',
    titleClass: 'text-green-800',
    textClass: 'text-green-700',
    Icon: FiCheckCircle
  },
  warning: {
    containerClass: 'bg-yellow-50',
    iconClass: 'text-yellow-400',
    titleClass: 'text-yellow-800',
    textClass: 'text-yellow-700',
    Icon: FiAlertCircle
  },
  error: {
    containerClass: 'bg-red-50',
    iconClass: 'text-red-400',
    titleClass: 'text-red-800',
    textClass: 'text-red-700',
    Icon: FiAlertCircle
  }
};

const Alert = ({ 
  variant = 'info', 
  title, 
  message, 
  onDismiss,
  className = '',
  showIcon = true,
  actions = []
}) => {
  const { containerClass, iconClass, titleClass, textClass, Icon } = variants[variant] || variants.info;
  
  return (
    <div className={`rounded-md p-4 ${containerClass} ${className}`} role="alert">
      <div className="flex">
        {showIcon && (
          <div className="flex-shrink-0">
            <Icon className={`h-5 w-5 ${iconClass}`} aria-hidden="true" />
          </div>
        )}
        <div className="ml-3 flex-1">
          {title && (
            <h3 className={`text-sm font-medium ${titleClass}`}>{title}</h3>
          )}
          {message && (
            <div className={`text-sm ${textClass} ${title ? 'mt-2' : ''}`}>
              {typeof message === 'string' ? <p>{message}</p> : message}
            </div>
          )}
          {actions.length > 0 && (
            <div className="mt-4">
              <div className="-mx-2 -my-1.5 flex">
                {actions.map((action, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={action.onClick}
                    className={`ml-3 rounded-md px-2 py-1.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 ${action.className || `bg-${variant}-100 text-${variant}-800 hover:bg-${variant}-200 focus:ring-${variant}-600`}`}
                  >
                    {action.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        {onDismiss && (
          <div className="ml-auto pl-3">
            <div className="-mx-1.5 -my-1.5">
              <button
                type="button"
                onClick={onDismiss}
                className={`inline-flex rounded-md p-1.5 focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                  variant === 'info' ? 'bg-blue-50 text-blue-500 hover:bg-blue-100 focus:ring-blue-600' :
                  variant === 'success' ? 'bg-green-50 text-green-500 hover:bg-green-100 focus:ring-green-600' :
                  variant === 'warning' ? 'bg-yellow-50 text-yellow-500 hover:bg-yellow-100 focus:ring-yellow-600' :
                  'bg-red-50 text-red-500 hover:bg-red-100 focus:ring-red-600'
                }`}
              >
                <span className="sr-only">Dismiss</span>
                <FiX className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Alert;
