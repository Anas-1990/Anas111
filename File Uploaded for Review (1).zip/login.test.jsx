import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { AuthProvider } from '../app/context/AuthContext';
import LoginPage from '../app/login/page';

// Mock the useRouter hook
jest.mock('next/navigation', () => ({
  useRouter: () => ({
    push: jest.fn(),
  }),
}));

// Mock Firebase Auth
jest.mock('firebase/auth', () => {
  const originalModule = jest.requireActual('firebase/auth');
  return {
    ...originalModule,
    getAuth: jest.fn(),
    createUserWithEmailAndPassword: jest.fn(),
    signInWithEmailAndPassword: jest.fn(),
    signInWithPopup: jest.fn(),
    GoogleAuthProvider: jest.fn().mockImplementation(() => {
      return {};
    }),
    onAuthStateChanged: jest.fn(),
    sendPasswordResetEmail: jest.fn(),
  };
});

// Mock Firebase app
jest.mock('firebase/app', () => ({
  initializeApp: jest.fn(),
}));

describe('LoginPage', () => {
  beforeEach(() => {
    // Reset mocks
    jest.clearAllMocks();
  });

  test('renders login form by default', () => {
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    expect(screen.getByText('Sign in to your account')).toBeInTheDocument();
    expect(screen.getByLabelText(/Email address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign in/i })).toBeInTheDocument();
    expect(screen.getByText(/Don't have an account?/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign up/i })).toBeInTheDocument();
  });

  test('switches to signup form when "Sign up" is clicked', () => {
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    fireEvent.click(screen.getByRole('button', { name: /Sign up/i }));
    
    expect(screen.getByText('Create a new account')).toBeInTheDocument();
    expect(screen.getByLabelText(/Full Name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Email address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign up/i })).toBeInTheDocument();
    expect(screen.getByText(/Already have an account?/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign in/i })).toBeInTheDocument();
  });

  test('shows password reset form when "Forgot your password?" is clicked', () => {
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    fireEvent.click(screen.getByText(/Forgot your password?/i));
    
    expect(screen.getByText('Reset your password')).toBeInTheDocument();
    expect(screen.getByLabelText(/Email address/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Send reset instructions/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Back to login/i })).toBeInTheDocument();
  });

  test('submits login form with correct values', async () => {
    const { signInWithEmailAndPassword } = require('firebase/auth');
    signInWithEmailAndPassword.mockResolvedValueOnce({ user: { uid: '123' } });
    
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    fireEvent.change(screen.getByLabelText(/Email address/i), {
      target: { value: 'test@example.com' },
    });
    
    fireEvent.change(screen.getByLabelText(/Password/i), {
      target: { value: 'password123' },
    });
    
    fireEvent.click(screen.getByRole('button', { name: /Sign in/i }));
    
    await waitFor(() => {
      expect(signInWithEmailAndPassword).toHaveBeenCalledWith(
        expect.anything(),
        'test@example.com',
        'password123'
      );
    });
  });

  test('submits signup form with correct values', async () => {
    const { createUserWithEmailAndPassword, updateProfile, sendEmailVerification } = require('firebase/auth');
    createUserWithEmailAndPassword.mockResolvedValueOnce({ 
      user: { 
        uid: '123',
        updateProfile: jest.fn().mockResolvedValueOnce({}),
        sendEmailVerification: jest.fn().mockResolvedValueOnce({})
      } 
    });
    
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    // Switch to signup form
    fireEvent.click(screen.getByRole('button', { name: /Sign up/i }));
    
    fireEvent.change(screen.getByLabelText(/Full Name/i), {
      target: { value: 'Test User' },
    });
    
    fireEvent.change(screen.getByLabelText(/Email address/i), {
      target: { value: 'test@example.com' },
    });
    
    fireEvent.change(screen.getByLabelText(/Password/i), {
      target: { value: 'password123' },
    });
    
    fireEvent.click(screen.getByRole('button', { name: /Sign up/i }));
    
    await waitFor(() => {
      expect(createUserWithEmailAndPassword).toHaveBeenCalledWith(
        expect.anything(),
        'test@example.com',
        'password123'
      );
    });
  });

  test('handles Google sign-in', async () => {
    const { signInWithPopup } = require('firebase/auth');
    signInWithPopup.mockResolvedValueOnce({ user: { uid: '123' } });
    
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    fireEvent.click(screen.getByRole('button', { name: /Google/i }));
    
    await waitFor(() => {
      expect(signInWithPopup).toHaveBeenCalled();
    });
  });

  test('submits password reset form with correct email', async () => {
    const { sendPasswordResetEmail } = require('firebase/auth');
    sendPasswordResetEmail.mockResolvedValueOnce({});
    
    render(
      <AuthProvider>
        <LoginPage />
      </AuthProvider>
    );
    
    // Switch to password reset form
    fireEvent.click(screen.getByText(/Forgot your password?/i));
    
    fireEvent.change(screen.getByLabelText(/Email address/i), {
      target: { value: 'test@example.com' },
    });
    
    fireEvent.click(screen.getByRole('button', { name: /Send reset instructions/i }));
    
    await waitFor(() => {
      expect(sendPasswordResetEmail).toHaveBeenCalledWith(
        expect.anything(),
        'test@example.com'
      );
    });
  });
});
